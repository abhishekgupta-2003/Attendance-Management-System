<?php

ob_start();
session_start();

if($_SESSION['name']!='oasiss')
{

  header('location: ../index.php');
}
?>
<?php include('connect.php');?>

<!DOCTYPE html>
<html lang="en">

<!-- head started -->
<head>
<title>Mehr Chand Polytechnic College Attendance Management System</title>
<meta charset="UTF-8">
  <link rel="stylesheet" type="text/css" href="../css/main.css">
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
   
  <!-- Optional theme -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
   
  <link rel="stylesheet" href="styles.css" >
   
  <!-- Latest compiled and minified JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>
<!-- head ended -->

<!-- body started -->
<body>

<!-- Menus started-->
<header>

  <h1>Mehr Chand Polytechnic College Attendance Management System</h1>
  <div class="navbar">
  <a href="index.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Home</a>
  <a href="students.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Students</a>
  <a href="report.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Report Section</a>
  <!-- <a href="account.php" style="text-decoration:none;">My Account</a> -->
  <a href="../logout.php?username=<?php echo $_GET['username']; ?>"  style="text-decoration:none;">Logout</a>

</div>

</header>
<!-- Menus ended -->
<?php 

$username=$_GET['username'];
  
?>
<center>

<!-- Content, Tables, Forms, Texts, Images started -->
<div class="row">

  <div class="content">
    <h3>Student Report</h3>
    <br>
    <form method="post" action="" class="form-horizontal col-md-6 col-md-offset-3">

  <div class="form-group">

    <label  for="input1" class="col-sm-3 control-label">Select Subject</label>
      <div class="col-sm-4">
      <select name="whichcourse" class="form-control" id="input1">

        
      <?php
       $qu = "SELECT Subject FROM subject";
      $re= mysqli_query($conn,$qu);
       while($r=mysqli_fetch_array($re))
       {
      
      ?>
        <option  >  <?php echo $r['Subject']; ?></option>

     
      <?php

       }
         ?>
    </select>
      </div>

  </div>

        <div class="form-group">
           <label for="input1" class="col-sm-3 control-label">Enter Roll NO</label>
              <div class="col-sm-7">
                  <input type="text" name="sr_id" class="form-control" id="input1" placeholder="enter roll no" value="<?php echo $username;?>"  disabled/>
              </div>
        </div>
        <input type="submit"  value="Go!" name="sr_btn" />
    </form>
    <br><br><br><br><br><br><br><br>
    <h3> One Day Report</h3><br>
    <form method="post" action="">

<label >Select Subject</label>
<select name="course1" >
  <?php
   $qu = "SELECT Subject FROM subject";
   $re=mysqli_query($conn,$qu);
   while($r=mysqli_fetch_array($re))
   {
  
  ?>
    <option  >  <?php echo $r['Subject']; ?></option>

 
  <?php

   }
     ?>
    

</select>
<p>  </p>
  <label>Date </label>
  <input type="date" name="date1">

  <label>Roll no.</label>
  <input type="text" name="roll1" value="<?php echo $username;?>" disabled>

  <input type="submit" name="sr_date1" value="Go!" >
</form>

    <br>

    <br>

   
    <div class="content"><br></div>

    <form method="post" action="" class="form-horizontal col-md-6 col-md-offset-3">
    <table class="table table-striped">

   <?php

    //checking the form for ID
    if(isset($_POST['sr_btn'])){

    //initializing ID 
    //  $sr_id = $_POST['sr_id'];
     $course = $_POST['whichcourse'];

     $i=0;
     $count_pre = 0;
     
     //query for searching respective ID
    //  $all_query = mysql_query("select * from reports where reports.st_id='$sr_id' and reports.course = '$course'");
    //  $count_tot = mysql_num_rows($all_query);
     $all_query = "select stat_id,count(*) as countP from attendance where attendance.stat_id='$_GET[username]' and attendance.course = '$course' and attendance.st_status='Present'";
     $singleT= "select count(*) as countT from attendance where attendance.stat_id='$_GET[username]' and attendance.course = '$course'";
     $re=mysqli_query($conn,$all_query);
     $sin=mysqli_query($conn,$singleT);
     $count_tot;
     if ($row=mysqli_fetch_row($sin))
     {
     $count_tot=$row[0];
     }

     while ($data = mysqli_fetch_array($re)) {
       $i++;
      //  if($data['st_status'] == "Present"){
      //     $count_pre++;
      //  }
       if($i <= 1){
     ?>
        

     <tbody>
      <tr>
          <td>Roll No.: </td>
          <td><?php echo $data['stat_id']; ?></td>
      </tr>

      <tr>
        <td>Total Class (Days): </td>
        <td><?php echo $count_tot; ?> </td>
      </tr>

      <tr>
        <td>Present (Days): </td>
        <td><?php echo $data[1]; ?> </td>
      </tr>

      <tr>
        <td>Absent (Days): </td>
        <td><?php echo $count_tot -  $data[1]; ?> </td>
      </tr>

    </tbody>

   <?php

     }  
    }}
     ?>
    </table>
  </form>
  </div>

</div>
<!-- Contents, Tables, Forms, Images ended -->

</center>

<div class="content"><br></div>

    <form method="post" action="" class="form-horizontal col-md-6 col-md-offset-3">
    <table class="table table-striped">

   <?php

    //checking the form for ID
    if(isset($_POST['sr_date1'])){

    //initializing ID 
    //  $sr_id = $_GET['username']
     $course = $_POST['course1'];
     $date = $_POST['date1'];

     $i=0;
     $count_pre = 0;
     
     //query for searching respective ID
    //  $all_query = mysql_query("select * from reports where reports.st_id='$sr_id' and reports.course = '$course'");
    //  $count_tot = mysql_num_rows($all_query);
     $all_query = "select stat_id,count(*) as countP from attendance where attendance.stat_id='$_GET[username]' and attendance.course = '$course' and attendance.stat_date='$date' and attendance.st_status='Present'";
     $singleT=" select count(*) as countT from attendance where attendance.stat_id='$_GET[username]' and attendance.stat_date='$date' and attendance.course = '$course'";
     $re=mysqli_query($conn,$all_query);
     $sin=mysqli_query($conn,$singleT);
     $count_tot;
     if ($row=mysqli_fetch_row($sin))
     {
     $count_tot=$row[0];
     }

     while ($data = mysqli_fetch_array($re)) {
       $i++;
    
       if($i <= 1){
     ?>
     <tbody>
      <tr>
          <td>Roll No.: </td>
          <td><?php echo $data['stat_id']; ?></td>
      </tr>

      <tr>
        <td>Total Class (Days): </td>
        <td><?php echo $count_tot; ?> </td>
      </tr>

      <tr>
        <td>Present (Days): </td>
        <td><?php echo $data[1]; ?> </td>
      </tr>

      <tr>
        <td>Absent (Days): </td>
        <td><?php echo $count_tot -  $data[1]; ?> </td>
      </tr>

    </tbody>

   <?php

     }  
    }}
     ?>
    </table>
  </form>
  </div>

</div>
<!-- Contents, Tables, Forms, Images ended -->

</center>

</body>


</html>
