<?php

ob_start();
session_start();

if($_SESSION['name']!='oasiss')
{

  header('location: ../index.php');
}
// print_r($_SESSION);
?>

<!DOCTYPE html>
<html lang="en">

<!-- head started -->
<head>
  <style>
    .font{
      font-family: "Times New Roman", Times, serif;
    }
    </style>
<title>Attendance Management System</title>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="../css/main.css">

</head>
<!-- head ended -->

<!-- body started -->
<body>

<!-- Menus started-->
<header>

  <h1 class="font">Mehr Chand Polytechnic College Attendance Management System</h1>
  <div class="navbar">
  <a href="index.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Home</a>
  <a href="students.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Students</a>
  <a href="report.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Report Section</a>
  <!-- <a href="account.php" style="text-decoration:none;">My Account</a> -->
  <a href="../logout.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Logout</a>

</div>

</header>
<!-- Menus ended -->

<center>
<?php $username=$_GET['username']; ?>
<!-- Content, Tables, Forms, Texts, Images started -->
<div class="row">
    <div class="content">
    <h1>Student Roll No:<?php echo $username; ?></h1>
    <img src="stua.jpg" alt="#" width="950"
    height="520" />

  </div>

</div>
<!-- Contents, Tables, Forms, Images ended -->

</center>

</body>
<!-- Body ended  -->

</html>
