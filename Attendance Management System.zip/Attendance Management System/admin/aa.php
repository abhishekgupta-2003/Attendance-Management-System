<?php
ob_start();
session_start();

if($_SESSION['name']!='oasis')
{

  header('location: ../index.php');
}

//establishing connection
include('connect.php');

?>

<?php

include('connect.php');





if(isset($_POST['save_multicheckbox']))
{ $r= $_GET[tc_id];
 $ra= $_GET[tc_name];
  $raa= $_GET[tc_email];
 $username=$_GET['username'];
    // $brandlist = $_POST['brandslist'];
    $brandlist = implode(",",$_POST['brandslist']);
    // foreach($brandlist as $sub)
    // {
        // echo $brandlist[$i]."<br>";
       
    // echo $sub."<br>";
    $query = "INSERT INTO `teachers`(`tc_id`,`tc_name`, `tc_dept`, `tc_email`, `tc_course`) VALUES ('$_GET[tc_id]','$_GET[tc_name]','$_GET[tc_dept]','$_GET[tc_email]','".$brandlist."')";
  $result = "INSERT INTO `admininfo`(`tc_name`,`username`, `email`, `pass`, `type`) VALUES ('$r','$ra','$raa','$ra','teacher')";
    mysqli_query($conn,$query);
        mysqli_query($conn,$result);
    header("location:index.php?username=$username");

}
?>
<?php 

// $username="princemadaan";
 $username=$_GET['username'];
//  echo $username
?>
<!DOCTYPE html>
<html lang="en">
<head>
  
    <title>Mehr Chand Polytechnic College Attendance Management System</title>


  <link rel="stylesheet" type="text/css" href="../css/main.css">
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
   
  <!-- Optional theme -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
   
  <link rel="stylesheet" href="styles.css" >
   
  <!-- Latest compiled and minified JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


</head>
<body>
<header>


<h1>Mehr Chand Polytechnic College Attendance Management System</h1>
      <div class="navbar">
       <a href="signup.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Create Users</a>
      <a href="index.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Add Student/Teacher</a>
      <a href="all_stu.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">View Students</a>
      <a href="v-teachers.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">View Teachers</a>
      <a href="Subject.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Add/View Subject</a>
      <a href="change_passA.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Change Password</a>
      <a href="../logout.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Logout</a>
      </div>

</header>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">

               
                <div class="card mt-5">
                    <div class="card-header">
                      
                    </div>
                    <div class="card-body">

                        <form  method="POST"  >
                        <?php
                           

                            $query_run = "SELECT Subject FROM subject";
                           $qu= mysqli_query($conn,$query_run);
                           while($r=mysqli_fetch_array($qu))
{
                            
                                
                                
                                    ?>
                               <h4>     <input type="checkbox" name="brandslist[] " value= "<?php echo $r['Subject']; ?>" /><?php echo $r['Subject']; ?> <br><h4>
                                    
                                    <?php
                                    
                                
                            
                          }
                        ?>
                            <div class="form-group mt-3">
                                <input type="hidden" name="tc_id" class="form-control" id="input1"  value="<?php echo $_GET['tc_id']?>" />
                            <input type="hidden" name="tc_name" class="form-control" id="input1"  value="<?php echo $_GET['tc_name']?>" />
						<input type="hidden" name="tc_dept" class="form-control" id="input1"  value="<?php echo $_GET['tc_dept']?>" />
						<input type="hidden" name="tc_email" class="form-control" id="input1"  value="<?php echo $_GET['tc_email']?>" />
							<input type="hidden" name="username" class="form-control" id="input1"  value="<?php echo $_GET['username']?>" />
                                <button name="save_multicheckbox" class="btn btn-primary">Save</button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>