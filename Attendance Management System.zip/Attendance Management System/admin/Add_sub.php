<?php

ob_start();
session_start();

if($_SESSION['name']!='oasis')
{

  header('location: ../index.php');
}


?>

<?php
//Databse connection file

//Databse connection file
include('connect.php');
// echo $_POST['tc_id'];
// echo $_POST['tc_name'];
// $tc_dept= $_POST['tc_dept'];
// $tc_email= $_POST['tc_email'];
// $tc_course= $_POST['tc_course'];


if(isset($_POST['submit']))
{
	// echo $_POST['tc_name'];
// $tc_dept= $_POST['tc_dept'];
// $tc_email= $_POST['tc_email'];
// $tc_course= $_POST['tc_course'];
	// Counting No fo skilss
$count = count($_POST["skill"]);
//Getting post values
$skill=$_POST["skill"];	
if($count >= 1)
{
	for($i=0; $i<$count; $i++)
	{
		if(trim($_POST["skill"][$i] != ''))
		{
			// $sql =mysql_query("INSERT INTO teachers(id,skill) VALUES('1','$skill[$i]')");
            // $sql=  mysql_query("INSERT INTO 'teachers' ('id','tc_name','tc_dept','tc_email','skill') VALUES ('1','e','ee','ff','$skill[$i]')");
			$sql=  "INSERT INTO `subject`( `Subject`) VALUES ('$skill[$i]')";
			mysqli_query($conn,$sql);
		$username=$_GET['username'];
			header("location:Subject.php?username=$username");  
		}

	}
echo "<script>alert('Skills inserted successfully');</script>";
}
else
{
echo "<script>alert('Please enter skill');</script>";
}
}
?>
<?php 

$username=$_GET['username'];
//   echo $username;
?>

<html>
	<head>

		
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
        <title>Mehr Chand Polytechnic College Attendance Management System</title>
<meta charset="UTF-8">

  <link rel="stylesheet" type="text/css" href="../css/main.css">
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
   
  <!-- Optional theme -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
   
  <link rel="stylesheet" href="styles.css" >
   
  <!-- Latest compiled and minified JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

        
	</head>
	<body>
    <header>

<h1>Mehr Chand Polytechnic College Attendance Management System</h1>
<div class="navbar">
  <a href="signup.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Create Users</a>
      <a href="index.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Add Student/Teacher</a>
      <a href="all_stu.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">View Students</a>
      <a href="v-teachers.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">View Teachers</a>
      <a href="Subject.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Add/View Subject</a>
      <a href="change_passA.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Change Password</a>
      <a href="../logout.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Logout</a>
</div>

</header>
		<div class="container">
			<br />
			<br />
			
			<div class="form-group">
				<form name="add_name" id="add_name" method="post">
					<div class="table-responsive">
						<table class="table table-bordered" id="dynamic_field">
							<tr>
								<td><input type="text" name="skill[]" pattern="[A-Z a-z]{1,50}" placeholder="Enter Subject" class="form-control name_list" required  /></td>
								<td><button type="button" name="add" id="add" class="btn btn-success">Add More</button></td>
							</tr>
					
						</table>
						
						<input type="submit" name="submit" id="submit" class="btn btn-info" value="Submit" />
						
					</div>
				</form>
			</div>
		</div>
	</body>
	<script>
$(document).ready(function(){
	var i=1;
	$('#add').click(function(){
		i++;
		$('#dynamic_field').append('<tr id="row'+i+'"><td><input type="text" name="skill[]" placeholder="Enter  Subject" class="form-control name_list" /></td><td><button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove">X</button></td></tr>');
	});
	
	$(document).on('click', '.btn_remove', function(){
		var button_id = $(this).attr("id"); 
		$('#row'+button_id+'').remove();
	});
});
</script>
</html>