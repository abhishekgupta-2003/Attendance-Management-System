<?php
ob_start();
session_start();

if($_SESSION['name']!='oasis')
{

  header('location: ../index.php');
}

?>
<?php
include 'connect.php';
$id=$_GET['id'];
// $su= $_GET['su'];

// $de="DELETE FROM students WHERE st_id=$_id";
$all_query= "DELETE FROM `subject` WHERE `id` = '$id'";
// // $all_query= mysql_query("DELETE FROM `teachers` WHERE `tc_course` = '$su'");
mysqli_query($conn,$all_query);
     $username=$_GET['username']; 
    

 header("location:View_sub.php? username=$username");  


?>