<?php
ob_start();
session_start();

if($_SESSION['name']!='oasis')
{

  header('location: ../index.php');
}

?>
<?php
include 'connect.php';
$tc_name=$_GET['tc_name'];
 $username=$_GET['username'];
// $de="DELETE FROM students WHERE st_id=$tc_id";
$all_query = "DELETE FROM `teachers` WHERE tc_id=$tc_name  ";

$all_quer= "DELETE FROM admininfo WHERE tc_name = $tc_name";
mysqli_query($conn,$all_query);
mysqli_query($conn,$all_quer);

        //   header("location:v-teachers.php");  
           header("location:v-teachers.php?username=$username"); 


?>