<?php

ob_start();
session_start();

if($_SESSION['name']!='oasis')
{

  header('location: ../index.php');
}

// session_start();

// if($_SESSION['name']!='oasis')
// {

//   header('location: ../index.php');
// }
?>

<?php

include('connect.php');

//data insertion
  try{

   
     $st_id=$_GET['st_id'];
     $qu ="SELECT * FROM `students` WHERE st_id='$st_id'";
     $q=mysqli_query($conn,$qu);
     if($ro=mysqli_fetch_array($q))
     {
      //  $st_id=$row['st_id'];
     
       $st_name=$ro['st_name'];
       $st_dept=$ro['st_dept'];
       $st_batch=$ro['st_batch'];
       $st_year=$ro['st_year'];
       $st_email=$ro['st_email'];
     }

        if(isset($_POST['std'])){

  
          $res = "UPDATE `students` SET  `st_name`='$_POST[st_name]',`st_dept`='$_POST[st_dept]',`st_batch`='$_POST[st_batch]',`st_year`='$_POST[st_year]',`st_email`='$_POST[st_email]' WHERE st_id='$st_id'";
          mysqli_query($conn,$res);
          $re="UPDATE `admininfo` SET `email`='$_POST[st_email]'  WHERE username='$st_id'";
          mysqli_query($conn,$re);
          $success_msg = "Student added successfully.";
          $sst_id= "1";
             $username=$_GET['username'];
          header("location:v-students.php? sst_id=$sst_id& username=$username");
    }
   

  }
  catch(Execption $e){
    $error_msg =$e->getMessage();
  }

 ?>
<?php 

$username=$_GET['username'];
  
?>


<!DOCTYPE html>
<html lang="en">
<!-- head started -->
<head>
<title>Attendance Management System</title>
<meta charset="UTF-8">

  <link rel="stylesheet" type="text/css" href="../css/main.css">
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
   
  <!-- Optional theme -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
   
  <link rel="stylesheet" href="styles.css" >
   
  <!-- Latest compiled and minified JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style type="text/css">

  .message{
    padding: 10px;
    font-size: 15px;
    font-style: bold;
    color: black;
  }
</style>
</head>
<!-- head ended -->

<!-- body started -->
<body>

    <!-- Menus started-->
    <header>

      <h1>Attendance Management System</h1>
      <div class="navbar">
       <a href="signup.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Create Users</a>
      <a href="index.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Add Student/Teacher</a>
      <a href="all_stu.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">View Students</a>
      <a href="v-teachers.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">View Teachers</a>
      <a href="Subject.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Add/View Subject</a>
      <a href="change_passA.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Change Password</a>
      <a href="../logout.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Logout</a>

    </div>

    </header>
    <!-- Menus ended -->

<center>
<!-- Error or Success Message printint started -->
<div class="message">
        <?php if(isset($success_msg)) echo $success_msg; if(isset($error_msg)) echo $error_msg; ?>
</div>
<!-- Error or Success Message printint ended -->

<!-- Content, Tables, Forms, Texts, Images started -->
<div class="content">

<br><br><br>
<div class="row" id="student">


       <form method="post" class="form-horizontal col-md-6 col-md-offset-3">
        <h2>Student Update</h2>
        <div class="form-group">
          <label for="input1" class="col-sm-3 control-label">Roll no</label>
          <div class="col-sm-7">
            <input type="text" name="st_id" pattern="[0-9]{3,4}(/){1}[0-9]{2}" class="form-control" id="input1" placeholder="Student roll no." value="<?php echo $ro['st_id'] ?>" disabled required />
          </div>
      </div>

      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label">Name</label>
          <div class="col-sm-7">
            <input type="text" name="st_name" pattern="[A-Z a-z]{1,50}" class="form-control" id="input1" placeholder="Student full name" value="<?php echo $ro['st_name']; ?>" required/>
          </div>
      </div>

      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label">Department</label>
          <div class="col-sm-7">
            <input type="text" name="st_dept" pattern="[A-Za-z]{1,50}" class="form-control" id="input1" placeholder="Department example CSE" value="<?php echo $ro['st_dept']; ?>" required/>
          </div>
      </div>

      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label">Batch</label>
          <div class="col-sm-7">
            <input type="text" name="st_batch" pattern="[0-9]{4}" class="form-control" id="input1" placeholder="Batch example 2022" value="<?php echo $ro['st_batch']; ?>" required/>
          </div>
      </div>

      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label">year</label>
          <div class="col-sm-7">
            <input type="text" name="st_year" pattern="[1-6]{1}" class="form-control" id="input1" placeholder="Year" value="<?php echo $ro['st_year']; ?>"required/>
          </div>
      </div>

      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label">Email</label>
          <div class="col-sm-7">
            <input type="text" name="st_email"  pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" class="form-control" id="input1" placeholder="Valid email" value="<?php echo $ro['st_email']; ?>" required/>
          </div>
      </div>


      <input type="submit" class="btn btn-primary col-md-2 col-md-offset-8" value="Update " name="std" required/>
    </form>

  </div>
<!-- Contents, Tables, Forms, Images ended -->

</center>
</body>
<!-- Body ended  -->
</html>
