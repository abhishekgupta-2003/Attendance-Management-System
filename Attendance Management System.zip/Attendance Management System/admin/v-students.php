<?php

ob_start();
session_start();

if($_SESSION['name']!='oasis')
{

  header('location: ../index.php');
}


?>


<?php

//establishing connection
include('connect.php');


?>
 <?php 

$username=$_GET['username'];
//   echo $username;
?>        

<!DOCTYPE html>
<html lang="en">

<!-- head started -->
<head>
<title>Mehr Chand Polytechnic College Attendance Management System</title>
<meta charset="UTF-8">

  <link rel="stylesheet" type="text/css" href="../css/main.css">
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
   
  <!-- Optional theme -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
   
  <link rel="stylesheet" href="styles.css" >
   
  <!-- Latest compiled and minified JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>
<!-- head ended -->

<!-- body started -->
<body>

    <!-- Menus started-->
    <header>

      <h1>Mehr Chand Polytechnic College Attendance Management System</h1>
      <div class="navbar">
      <a href="signup.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Create Users</a>
      <a href="index.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Add Student/Teacher</a>
      <a href="all_stu.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">View Students</a>
      <a href="v-teachers.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">View Teachers</a>
      <a href="Subject.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Add/View Subject</a>
      <a href="change_passA.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Change Password</a>
      <a href="../logout.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Logout</a>
      </div>

    </header>
    <!-- Menus ended -->
   

<center>
<h1><?php echo $_GET['sst_id']; $ss='1'; ?> Year Students</h1>
</center>

<p style = "margin-left: 1190px; ">
    <?php
  if($_GET['sst_id']==1)
  {
     


  ?>
  Update all student year
    <a style="text-decoration: none; color:OrangeRed" href=udate_allstu.php?st_year=1&username=<?php echo $_GET['username'];?>
                 data-toggle="tooltip" data-placement="bottom" title="UPDATE" ><button class="btn btn-info">UPDATE</button></a> 
  <?php
  }if($_GET['sst_id']==2)
  {
     


  ?>
  Update all student year
    <a style="text-decoration: none; color:OrangeRed" href=udate_allstu.php?st_year=2&username=<?php echo $_GET['username'];?>
                 data-toggle="tooltip" data-placement="bottom" title="UPDATE"  ><button class="btn btn-info">UPDATE</button></a> 
  <?php
  }
  ?>
  <?php
  if($_GET['sst_id']==3)
  {
     

?>
 
  Delete all Student Year :
    <a style="text-decoration: none; color:OrangeRed" href=S_deleteall.php?st_year=3&username=<?php echo $_GET['username'];?> onClick="return ch()"
                 data-toggle="tooltip" data-placement="bottom" title="DELETE" ><button class="btn btn-danger" >DELETE</button></a>
  <?php
  }
  ?>
  <?php 

$username=$_GET['username'];
//   echo $username;
?>
  </p>

<center>
<div class="content">

  <div class="row">
  
  


    <table class="table table-striped table-hover">
      
        <thead>
        <tr>
          <th scope="col">Registration No.</th>
          <th scope="col">Name</th>
          <th scope="col">Department</th>
          <th scope="col">Batch</th>
          <th scope="col">Year</th>
          <th scope="col">Email</th>
          <th scope="col">Operation</th>
        </tr>
        </thead>
     <?php
     if($_GET['sst_id']==1 )
{      
       $i=0;
       
       $all_query = "SELECT * from students WHERE st_year=1 ";
    $re =  mysqli_query($conn,$all_query);
       
       while ($data = mysqli_fetch_array($re)) {
         $i++;
         
       ?>
  <div >
     
</div>
       <tr>
         <td><?php echo $data['st_id']; ?></td>
         <td><?php echo $data['st_name']; ?></td>
         <td><?php echo $data['st_dept']; ?></td>
         <td><?php echo $data['st_batch']; ?></td>
         <td><?php echo $data['st_year']; ?></td>
         <td><?php echo $data['st_email']; ?></td>
         <td > 
             <a style="text-decoration: none; color:OrangeRed" href="S_updateall1.php?st_id=<?php echo $data['st_id']; ?>&username=<?php echo $_GET['username'];?>"
             data-toggle="tooltip" data-placement="bottom" title="UPDATE" ><button class="btn btn-info">UPDATE</button></a>
                  
             <a  href=S_delete3.php?st_id=<?php echo $data['st_id'];  ?>&username=<?php echo $_GET['username'];?> onClick="return ch()"
                   data-toggle="tooltip" data-placement="top" title="DELETE">
                   <button class="btn btn-danger">DELETE</button></a> 
                  <!-- <td><input type="button" onClick="deleteid( <?php echo $row['st_id']; ?>)" name="Delete" value="Delete"></td> -->
               <?php 

$username=$_GET['username'];
//   echo $username;
?>        
            </td> 
       </tr>
       <!-- <script language="javascript">
         function deleteid(st_id)
         {
           if(confirm("Do you want Delete :")){
             window.location.href='S_delete3.php?st_id=' +st_id+'';
             return true;
           }
         }
   -->
       <?php 
            } 
}
// 2nd
elseif($_GET['sst_id']==2 )
{      
  $i=0;
       
  $all_query = "SELECT * from students WHERE st_year=2 ";
$re =  mysqli_query($conn,$all_query);
  
  while ($data = mysqli_fetch_array($re)) {
    $i++;
         
       ?>
  
       <tr>
         <td><?php echo $data['st_id']; ?></td>
         <td><?php echo $data['st_name']; ?></td>
         <td><?php echo $data['st_dept']; ?></td>
         <td><?php echo $data['st_batch']; ?></td>
         <td><?php echo $data['st_year']; ?></td>
         <td><?php echo $data['st_email']; ?></td>
         <td > 
             <a style="text-decoration: none; color:OrangeRed" href=S_updateall2.php?st_id=<?php echo $data['st_id']; ?>&username=<?php echo $_GET['username'];?>" href =S_update.php?ss =<?php $_GET['sst_id'] ?>&username=<?php echo $_GET['username'];?>"
             data-toggle="tooltip" data-placement="bottom" title="UPDATE" ><button class="btn btn-info">UPDATE</button></a>
                  
               <a  href=S_delete2.php?st_id=<?php echo $data['st_id'];  ?>&username=<?php echo $_GET['username'];?> onClick="return ch()"
                   data-toggle="tooltip" data-placement="top" title="DELETE">
                   <button class="btn btn-danger">DELETE</button></a> 
               <?php 

$username=$_GET['username'];
//   echo $username;
?>        
            </td> 
       </tr>
  
       <?php 
            } 
}
elseif($_GET['sst_id']==3)
{      

  $i=0;
       
  $all_query = "SELECT * from students WHERE st_year=3";
$re =  mysqli_query($conn,$all_query);
  
  while ($data = mysqli_fetch_array($re)) {
    $i++;
         
         
       ?>
  
       <tr>
         <td><?php echo $data['st_id']; ?></td>
         <td><?php echo $data['st_name']; ?></td>
         <td><?php echo $data['st_dept']; ?></td>
         <td><?php echo $data['st_batch']; ?></td>
         <td><?php echo $data['st_year']; ?></td>
         <td><?php echo $data['st_email']; ?></td>
         <td > 
             <a style="text-decoration: none; color:OrangeRed" href=S_updateall3.php?st_id=<?php echo $data['st_id']; ?>&username=<?php echo $_GET['username'];?> 
             href =S_update.php?ss =<?php  echo $_GET['sst_id'];  ?>&username=<?php echo $_GET['username'];?>
             data-toggle="tooltip" data-placement="bottom" title="UPDATE" ><button class="btn btn-info">UPDATE</button></a>
                  
             <a  href=" S_delete.php?st_id=<?php echo $data['st_id']; ?>"&username=<?php echo $_GET['username'];?> 
             onClick="return ch()"
                   data-toggle="tooltip" data-placement="top" title="DELETE">
                   <button class="btn btn-danger">DELETE</button></a> 
               <?php 

$username=$_GET['username'];
//   echo $username;
?>      
            </td> 
       </tr>
  
       <?php 
            } 
} 

        ?>  
        
      </table>
      <script language="javascript">
         function ch()
         {
          
         return  confirm('Do you want to Delete :');
         }
         </script>
    
  </div>
 
</div>


</center>

</body>
<!-- Body ended  -->

</html>