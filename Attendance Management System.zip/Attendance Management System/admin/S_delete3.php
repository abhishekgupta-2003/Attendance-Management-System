<?php
ob_start();
session_start();

if($_SESSION['name']!='oasis')
{

  header('location: ../index.php');
}

?>
<?php
include 'connect.php';
$st_id=$_GET['st_id'];


$sst_id= "1";
// $de="DELETE FROM students WHERE st_id=$_id";
$all_query= "DELETE FROM  students WHERE st_id= '$st_id'";
mysqli_query($conn,$all_query);
$all_quer= "DELETE FROM `admininfo` WHERE `username` = '$st_id'";
mysqli_query($conn,$all_quer);

     $username=$_GET['username']; 
    
    // echo $username;
    
 header("location:v-students.php? sst_id=$sst_id& username=$username");  


?>

