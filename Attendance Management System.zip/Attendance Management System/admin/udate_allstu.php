<?php

ob_start();
session_start();

if($_SESSION['name']!='oasis')
{

  header('location: ../index.php');
}

// session_start();

// if($_SESSION['name']!='oasis')
// {

//   header('location: ../index.php');
// }
?>

<?php

include('connect.php'); 

//data insertion
  

     if(isset($_POST['tcru'])){
      $st_year=$_GET['st_year'];

    $res = "UPDATE `students` SET  `st_year`='$_POST[year]' WHERE st_year='$st_year'";
    mysqli_query($conn,$res);
    // $success_msg = "All Students Are Shifted $st_year year to  $_POST[year] year";
    $username=$_GET['username'];
    header("location:v-students.php? sst_id=$_POST[year]&username=$username");
// echo $st_year;   
}


    
 ?>
<?php 

$username=$_GET['username'];
//   echo $username;
//   $st_year=$_GET['st_year'];
//   echo $st_year;
?>


<!DOCTYPE html>
<html lang="en">
<!-- head started -->
<head>
<title>Mehr Chand Polytechnic College Attendance Management System</title>
<meta charset="UTF-8">

  <link rel="stylesheet" type="text/css" href="../css/main.css">
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
   
  <!-- Optional theme -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
   
  <link rel="stylesheet" href="styles.css" >
   
  <!-- Latest compiled and minified JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style type="text/css">

  .message{
    padding: 10px;
    font-size: 15px;
    font-style: bold;
    color: black;
  }
</style>
</head>
<!-- head ended -->

<!-- body started -->
<body>

    <!-- Menus started-->
    <header>

      <h1>Mehr Chand Polytechnic College Attendance Management System</h1>
      <div class="navbar">
       <a href="signup.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Create Users</a>
      <a href="index.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Add Student/Teacher</a>
      <a href="all_stu.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">View Students</a>
      <a href="v-teachers.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">View Teachers</a>
      <a href="Subject.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Add/View Subject</a>
      <a href="change_passA.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Change Password</a>
      <a href="../logout.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Logout</a>

    </div>

    </header>
    <!-- Menus ended -->

<center>
<!-- Error or Success Message printint started -->
<div class="message">
        <?php if(isset($success_msg)) echo $success_msg; if(isset($error_msg)) echo $error_msg; ?>
</div>
<!-- Error or Success Message printint ended -->

<!-- Content, Tables, Forms, Texts, Images started -->
<div class="content">

<br><br><br>
  <div class="rowtwo" id="teacher">
  

       <form method="post" class="form-horizontal col-md-6 col-md-offset-3">
       

      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label">Enter Year</label>
          <div class="col-sm-7">
            <input type="text" name="year"   class="form-control" id="input1" placeholder="Enter Year"  required/>
          </div>
      </div>

      
     

      <input type="submit" class="btn btn-primary col-md-2 col-md-offset-8" value="Update" name="tcru" required/>
    </form>
    
  </div>
 <?php

    ?>

</div><br>
<!-- Contents, Tables, Forms, Images ended -->

</center>
</body>
<!-- Body ended  -->
</html>
  
