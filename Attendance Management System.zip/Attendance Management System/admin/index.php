<?php

ob_start();
session_start();

if($_SESSION['name']!="oasis")
{

  header('location: ../index.php');
}
// print_r($_SESSION);
 ?>

<?php

include('connect.php');

//data insertion
  try{

    //checking if the data comes from students form
    if(isset($_POST['std'])){

      //students data insertion to database table "students"
        $result = "INSERT INTO `students`(`st_id`,`st_name`,`st_dept`,`st_batch`,`st_year`,`st_email`,`username`,`password`) values('$_POST[st_id]','$_POST[st_name]','$_POST[st_dept]','$_POST[st_batch]','$_POST[st_year]','$_POST[st_email]','$_POST[st_name]','$_POST[st_id]')";
        //  $resul = "INSERT INTO `admininfo`(`username`, `email`, `pass`, `type`) VALUES ('$_POST[st_id]','$_POST[st_email]','$_POST[st_id]','student')";
          $resul = "INSERT INTO `admininfo`(`tc_name`,`username`,`email`,`pass`,`type`) VALUES ('','$_POST[st_id]','$_POST[st_email]','$_POST[st_id]','student')";
        mysqli_query($conn,$result);
        mysqli_query($conn,$resul);
        $success_msg = "Student added successfully.";

    }

        //checking if the data comes from teachers form
        if(isset($_POST['tcr'])){
         
     
         $tc_name= $_POST['tc_name'];
         $tc_dept= $_POST['tc_dept'];
         $tc_email= $_POST['tc_email'];
        //   $username=$_POST['username'];
         

          // //teachers data insertion to the database table "teachers"
          // $res = mysql_query("insert into teachers(tc_id,tc_name,tc_dept,tc_email,tc_course) values('$_POST[tc_id]','$_POST[tc_name]','$_POST[tc_dept]','$_POST[tc_email]','$_POST[tc_course]')");
          // $success_msg = "Teacher added successfully.";
    }

  }
  catch(Execption $e){
    $error_msg =$e->getMessage();
  }

 ?>
<?php 

$username=$_GET['username'];
//   echo $username;
?>


<!DOCTYPE html>
<html lang="en">
<!-- head started -->
<head>
<title>Mehr Chand Polytechnic College Attendance Management System</title>
<meta charset="UTF-8">

  <link rel="stylesheet" type="text/css" href="../css/main.css">
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
   
  <!-- Optional theme -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
   
  <link rel="stylesheet" href="styles.css" >
   
  <!-- Latest compiled and minified JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style type="text/css">

  .message{
    padding: 10px;
    font-size: 15px;
    font-style: bold;
    color: black;
  }
</style>
</head>
<!-- head ended -->

<!-- body started -->
<body>

    <!-- Menus started-->
    <header>

      <h1>Mehr Chand Polytechnic College Attendance Management System</h1>
      <div class="navbar">
    <a href="signup.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Create Users</a>
      <a href="index.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Add Student/Teacher</a>
      <a href="all_stu.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">View Students</a>
      <a href="v-teachers.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">View Teachers</a>
      <a href="Subject.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Add/View Subject</a>
      <a href="change_passA.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Change Password</a>
      <a href="../logout.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Logout</a>

    </div>

    </header>
    <!-- Menus ended -->

<center>
<!-- Error or Success Message printint started -->
<div class="message">
        <?php if(isset($success_msg)) echo $success_msg; if(isset($error_msg)) echo $error_msg; ?>
</div>
<!-- Error or Success Message printint ended -->

<!-- Content, Tables, Forms, Texts, Images started -->
<div class="content">

  <center> Select: <a href="#teacher">Teacher</a> | <a href="">Student</a> <br></center>

  <div class="row" id="student">



      <form method="post" class="form-horizontal col-md-6 col-md-offset-3">
      <h4>Add Student's Information</h4>
      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label">Roll no</label>
          <div class="col-sm-7">
            <input type="text" name="st_id" pattern="[0-9]{3,4}(/){1}[0-9]{2}" class="form-control" id="input1" placeholder="Enter Student Roll No" title="e.g 508/19"required />
          </div>
      </div>

      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label">Name</label>
          <div class="col-sm-7">
            <input type="text" name="st_name" pattern="[A-Z a-z]{1,50}" class="form-control" id="input1" placeholder="Enter Student Name" title="Only used Alphabets" required/>
          </div>
      </div>

      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label">Department</label>
          <div class="col-sm-7">
          <select name="st_dept" id="tc_dept"class="form-control" >
  <option value="CSE">CSE</option>
  <option value="ECE">ECE</option>
  <option value="CIVIL">CIVIL</option>
  <option value="ELECTRICAL">ELECTRICAL </option>
  <option value="MECHANICAL">MECHANICAL </option>
  <option value="AUTOMOBILE">AUTOMOBILE </option>
</select>
          </div>
      </div>

      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label">Batch</label>
          <div class="col-sm-7">
            <input type="text" name="st_batch" pattern="[0-9]{4}" class="form-control" id="input1" placeholder="Enter Student Batch No" title="e.g 2022"required/>
          </div>
      </div>

    

      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label" >Year</label>
          <div class="col-sm-7">
          
                <!-- <input type="text" name="whichbatch" id="input2" placeholder="Enter the Year"  required/> -->
                <select name="st_year" id="input2" value="whichbatch" class="form-control"  >
  <option value="1">1</option>
  <option value="2">2</option>


</select>
          </div>
      </div>

      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label">Email</label>
          <div class="col-sm-7">
            <input type="text" name="st_email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" class="form-control" id="input1" placeholder="Enter Student Email" title="e.g student@gmail.com" required/>
          </div>
      </div>

      <input type="submit" class="btn btn-primary col-md-2 col-md-offset-8" value="Add Student" name="std" required/>
    </form>

  </div>
<br><br><br>
  <div class="rowtwo" id="teacher">
  <?php
    //  $tcr_query ="select tc_id from teachers ";
    //   $re= mysqli_query($conn,$tcr_query);
    //         while($tcr_data = mysqli_fetch_array($re)){
            
    //           echo $tcr_data['tc_id']; 
    //         }
  $d="SELECT AUTO_INCREMENT
FROM information_schema.tables
WHERE table_name = 'teachers'
AND table_schema = 'attmgsystem'" ;
$r=mysqli_query($conn,$d);
$row = mysqli_fetch_assoc($r);
        $next_increment = $row['AUTO_INCREMENT'];
        // echo $next_increment;
    
    
  ?>

       <form action="aa.php" method="GET" class="form-horizontal col-md-6 col-md-offset-3">
        <h4>Add Teacher's Information</h4>
      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label">Teacher ID</label>
          <div class="col-sm-7">
            <input type="text" name="tc_id"  class="form-control" id="input1" value="<?php echo $next_increment; ?> " />
          </div>
      </div>

      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label">Name</label>
          <div class="col-sm-7">
            <input type="text" name="tc_name" pattern="[A-Z a-z]{1,50}" class="form-control" id="input1" placeholder="Enter Teacher Name" title="Only used Alphabets" required/>
          </div>
      </div>

      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label">Department</label>
          <div class="col-sm-7">
         

<select name="tc_dept" id="tc_dept"class="form-control" >
  <option value="CSE">CSE</option>
  <option value="ECE">ECE</option>
  <option value="CIVIL">CIVIL</option>
  <option value="ELECTRICAL">ELECTRICAL </option>
  <option value="MECHANICAL">MECHANICAL </option>
  <option value="AUTOMOBILE">AUTOMOBILE </option>
</select>
            
          </div>
      </div>

      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label">Email</label>
          <div class="col-sm-7">
            <input type="text" name="tc_email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" class="form-control" id="input1" placeholder="Enter Teacher Email" title="e.g teacher@gmail.com" required/>
          </div>
      </div>

      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label">Subject Name</label>
          <div class="col-sm-7">
            <input type="text" name="tc_course" pattern="[A-Z a-z]{1,50}" class="form-control" id="input1" placeholder="Enter Teacher Subject" title="Only used Alphabets" disabled required/><br>
            </div>
            </div>
             <div class="form-group">
          <label for="input1" class="col-sm-3 control-label"></label>
          <div class="col-sm-7">
            <input type="hidden" name="username" value="<?php echo $username ?>" class="form-control" id="input1" ><br>
      <input type="submit" class="btn btn-primary col-md-4 col-md-offset-8" value="Add Subject" name="tcr" required/>

          </div>
      </div>
   
    </form>
    
  </div>


</div><br>
<!-- Contents, Tables, Forms, Images ended -->

</center>
</body>
<!-- Body ended  -->
</html>
