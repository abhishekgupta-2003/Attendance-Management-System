<?php
ob_start();
session_start();

if($_SESSION['name']!='oasis')
{

  header('location: ../index.php');
}
//establishing connection
include('connect.php');


$i=0;
$tcr_query = "SELECT `tc_course` FROM `teachers` WHERE tc_id='$_GET[tc_id]'";
$q=mysqli_query($conn,$tcr_query);
while($tcr_data = mysqli_fetch_array($q)){

 $i++;
    
 $su= $tcr_data['tc_course'];
//  echo $su;
}
?>
	
<?php

include('connect.php');



try{

if(isset($_POST['save_multicheckbox']))
{
    if(empty($_POST['brandslist'])){
        throw new Exception("Select Atleast One Subject.");}

    
          
    // $brandlist = $_POST['brandslist'];
    $brandlist = implode(",",$_POST['brandslist']);
    // foreach($brandlist as $sub)
    // {
        // echo $brandlist[$i]."<br>";
       
    // echo $sub."<br>";
    $query ="UPDATE `teachers` SET `tc_course`='$su,".$brandlist."' WHERE tc_id='$_POST[tc_id]'";
    mysqli_query($conn,$query);
  $username=$_GET['username'];
              header("location:v-teachers.php? username=$username");  

}
}
catch(Exception $e){
  $error_msg =$e->getMessage();
}
?>
<?php 

$username=$_GET['username'];
  
?>

<!DOCTYPE html>
<html lang="en">
<head>
  
    <title>Mehr Chand Polytechnic College Attendance Management System</title>


  <link rel="stylesheet" type="text/css" href="../css/main.css">
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
   
  <!-- Optional theme -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
   
  <link rel="stylesheet" href="styles.css" >
   
  <!-- Latest compiled and minified JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


</head>
<body>
<header>


<h1>Mehr Chand Polytechnic College Attendance Management System</h1>
      <div class="navbar">
         <a href="signup.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Create Users</a>
      <a href="index.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Add Student/Teacher</a>
      <a href="all_stu.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">View Students</a>
      <a href="v-teachers.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">View Teachers</a>
      <a href="Subject.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Add/View Subject</a>
      <a href="change_passA.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Change Password</a>
      <a href="../logout.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Logout</a>
      </div>

</header>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">

 
                <div class="card mt-5">
                    <div class="card-header">
                      
                    </div>
                    <div class="card-body">

                        <form  method="POST"  >
                        <?php
                           

                            $query_run ="SELECT Subject FROM subject";
                        $q=    mysqli_query($conn,$query_run);
                           while($r=mysqli_fetch_array($q))
{
                            
                                
                                
                                    ?>
                              <h4   >      <input type="checkbox" name="brandslist[] " value= "<?php echo $r['Subject']; ?>"  /><?php echo $r['Subject']; ?> <br><h4>
                                    
                                    <?php
                                    
                                
                            
                          }
                        ?>
                        <br>
                            <div class="form-group mt-3">
                            <input type="hidden" name="tc_id" class="form-control" id="input1"  value="<?php echo $_GET['tc_id']?>" />
                            <input type="hidden" name="tc_name" class="form-control" id="input1"  value="<?php echo $_POST['tc_name']?>" />
						<input type="hidden" name="tc_dept" class="form-control" id="input1"  value="<?php echo $_POST['tc_dept']?>" />
						<input type="hidden" name="tc_email" class="form-control" id="input1"  value="<?php echo $_POST['tc_email']?>" />
                        <input type="hidden" name="tc_course" class="form-control" id="input1" placeholder="Subject ex. Software Engineering" value="<?php echo $course; ?>" required/>   
                        <button name="save_multicheckbox"  class="btn btn-primary col-md-2 col-md-offset-2  ">Save</button>
                            </div>
                       

                    </div>
                </div>
            </div>
            
        </div>
        <from>
        
                        </form>
    </div>
    <center> <h3>          <?php
//printing error message
if(isset($error_msg))
{
	echo $error_msg;
}
?><h3></center>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>