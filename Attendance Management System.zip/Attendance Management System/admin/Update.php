<?php

ob_start();
session_start();

if($_SESSION['name']!='oasis')
{

  header('location: ../index.php');
}

// session_start();

// if($_SESSION['name']!='oasis')
// {

//   header('location: /index.php');

?>

<?php

include('connect.php'); 

//data insertion
  try{

     $tc_id=$_GET['tc_id'];
   
     $q ="SELECT * FROM `teachers`  WHERE tc_id=$tc_id";
    $qu= mysqli_query($conn,$q);
     if($row=mysqli_fetch_array($qu))
     {
       $id=$row['tc_id'];
     
       $name=$row['tc_name'];
       $dept=$row['tc_dept'];
       $email=$row['tc_email'];
       $course=$row['tc_course'];
     }


        if(isset($_POST['tcru'])){
     
          $res ="UPDATE `teachers` SET  `tc_name`='$_POST[tc_name]',`tc_dept`='$_POST[tc_dept]',`tc_email`='$_POST[tc_email]',`tc_course`='$_POST[tc_course]' WHERE tc_id=$tc_id";
         
          $re="UPDATE `admininfo` SET `username`='$_POST[tc_name]', `email`='$_POST[tc_email]' WHERE tc_name=$tc_id";
           mysqli_query($conn,$res);
          mysqli_query($conn,$re);
          $success_msg = "Teacher update successfully.";
          $username=$_GET['username'];
        //   header("location:v-teachers.php");  
           header("location:v-teachers.php? username=$username");  
    }

  }
  catch(Execption $e){
    $error_msg =$e->getMessage();
  }

 ?>
 <?php 

$username=$_GET['username'];

  
?>



<!DOCTYPE html>
<html lang="en">
<!-- head started -->
<head>
<title>Mehr Chand Polytechnic College Attendance Management System</title>
<meta charset="UTF-8">

  <link rel="stylesheet" type="text/css" href="../css/main.css">
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
   
  <!-- Optional theme -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
   
  <link rel="stylesheet" href="styles.css" >
   
  <!-- Latest compiled and minified JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style type="text/css">

  .message{
    padding: 10px;
    font-size: 15px;
    font-style: bold;
    color: black;
  }
</style>
</head>
<!-- head ended -->

<!-- body started -->
<body>

    <!-- Menus started-->
    <header>

      <h1>Mehr Chand Polytechnic College Attendance Management System</h1>
      <div class="navbar">
  <a href="signup.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Create Users</a>
      <a href="index.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Add Student/Teacher</a>
      <a href="all_stu.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">View Students</a>
      <a href="v-teachers.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">View Teachers</a>
      <a href="Subject.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Add/View Subject</a>
      <a href="change_passA.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Change Password</a>
      <a href="../logout.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Logout</a>

    </div>

    </header>
    <!-- Menus ended -->

<center>
<!-- Error or Success Message printint started -->
<div class="message">
        <?php if(isset($success_msg)) echo $success_msg; if(isset($error_msg)) echo $error_msg; ?>
</div>
<!-- Error or Success Message printint ended -->

<!-- Content, Tables, Forms, Texts, Images started -->
<div class="content">

<br><br><br>
  <div class="rowtwo" id="teacher">
  

       <form method="post" class="form-horizontal col-md-6 col-md-offset-3">
        <h4>Add Teacher's Information</h4>
      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label">Teacher ID</label>
          <div class="col-sm-7">
            <input type="text" name="tc_id" pattern="[1-9]{1,50}" class="form-control" id="input1" placeholder="Teacher's id" value="<?php echo $id; ?>"  disabled required/>
          </div>
      </div>

      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label">Name</label>
          <div class="col-sm-7">
            <input type="text" name="tc_name" pattern="[A-Z a-z]{1,50}" class="form-control" id="input1" placeholder="Teacher full name" value="<?php echo $row['tc_name'] ?>" required/>
          </div>
      </div>

      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label">Department</label>
          <div class="col-sm-7">
            <input type="text" name="tc_dept" pattern="[A-Z a-z]{1,50}"  class="form-control" id="input1" placeholder="Department ex. CSE" value="<?php echo $row[ 'tc_dept'] ?>" required/>
          </div>
      </div>

      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label">Email</label>
          <div class="col-sm-7">
            <input type="email" name="tc_email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" class="form-control" id="input1" placeholder="Valid email" value="<?php echo $email; ?>" required/>
          </div>
      </div>

      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label">Subject Name</label>
          <div class="col-sm-7">
            <input type="text" name="tc_course" class="form-control" id="input1" placeholder="Subject ex. Software Engineering" value="<?php echo $course; ?>" required/>
          </div>
      </div>

      <input type="submit" class="btn btn-primary col-md-2 col-md-offset-8" value="Update Teacher" name="tcru" required/>
    </form>
    
  </div>


</div><br>
<!-- Contents, Tables, Forms, Images ended -->

</center>
</body>
<!-- Body ended  -->
</html>
