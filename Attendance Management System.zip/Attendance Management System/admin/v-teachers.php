<?php

ob_start();
session_start();

if($_SESSION['name']!='oasis')
{

  header('location: ../index.php');
}


?>


<?php

//establishing connection
include('connect.php');

  try{

    //validation of empty fields
      if(isset($_POST['signup'])){

        if(empty($_POST['email'])){
          throw new Exception("Email cann't be empty.");
        }

          if(empty($_POST['uname'])){
             throw new Exception("Username cann't be empty.");
          }

            if(empty($_POST['pass'])){
               throw new Exception("Password cann't be empty.");
            }
              
              if(empty($_POST['fname'])){
                 throw new Exception("Username cann't be empty.");
              }
                if(empty($_POST['phone'])){
                   throw new Exception("Username cann't be empty.");
                }
                  if(empty($_POST['type'])){
                     throw new Exception("Username cann't be empty.");
                  }

        //insertion of data to database table admininfo
        $result = "insert into admininfo(username,password,email,fname,phone,type) values('$_POST[uname]','$_POST[pass]','$_POST[email]','$_POST[fname]','$_POST[phone]','$_POST[type]')";
        mysqli_query($conn,$result);
        $success_msg="Signup Successfully!";

  
  }
}
  catch(Exception $e){
    $error_msg =$e->getMessage();
  }

?>
<?php 

$username=$_GET['username'];
// echo $username;
  
?>
<!DOCTYPE html>
<html lang="en">

<!-- head started -->
<head>
<title>Mehr Chand Polytechnic College Attendance Management System</title>
<meta charset="UTF-8">

  <link rel="stylesheet" type="text/css" href="../css/main.css">
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
   
  <!-- Optional theme -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
   
  <link rel="stylesheet" href="styles.css" >
   
  <!-- Latest compiled and minified JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>
<!-- head ended -->

<!-- body started -->
<body>

    <!-- Menus started-->
    <header>

      <h1>Mehr Chand Polytechnic College Attendance Management System</h1>
      <div class="navbar">
        <a href="signup.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Create Users</a>
      <a href="index.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Add Student/Teacher</a>
      <a href="all_stu.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">View Students</a>
      <a href="v-teachers.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">View Teachers</a>
      <a href="Subject.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Add/View Subject</a>
      <a href="change_passA.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Change Password</a>
      <a href="../logout.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Logout</a>
      </div>

    </header>
    <!-- Menus ended -->

<center>
<h1>All Teachers</h1>

<div class="content">

  <div class="row">
   
  <table class="table table=stripped table-hover">
        <thead>  
          <tr>
            <th scope="col">Teacher ID</th>
            <th scope="col">Name</th>
            <th scope="col">Department</th>
            <th scope="col">Email</th>
            <th scope="col">Subject</th>
            <th scope="col">Operation</th>
            <th scope="col">Add Subject</th>

          </tr>
        </thead>

      <?php

        $i=0;
        $tcr_query = "select * from teachers order by tc_id asc";
        $tcr=mysqli_query($conn,$tcr_query);
        while($tcr_data = mysqli_fetch_array($tcr)){
          $i++;

        ?>
          <tbody>
              <tr>
                <td><?php echo $tcr_data['tc_id']; ?></td>
                <td><?php echo $tcr_data['tc_name']; ?></td>
                <td><?php echo $tcr_data['tc_dept']; ?></td>
                <td><?php echo $tcr_data['tc_email']; ?></td>
                <td><?php echo $tcr_data['tc_course']; ?></td>
                   <td > 
                   <a style="text-decoration: none; color:OrangeRed" href=Update.php?tc_id=<?php echo $tcr_data['tc_id']; ?>&username=<?php echo $_GET['username'];?>
                   data-toggle="tooltip" data-placement="bottom" title="UPDATE" ><button class="btn btn-info">UPDATE</button></a>
                  
                   <a  href=Delete.php?tc_name=<?php echo $tcr_data['tc_id']; ?>&username=<?php echo $_GET['username'];?> onClick="return ch()"
                   data-toggle="tooltip" data-placement="top" title="DELETE">
                   <button class="btn btn-danger">DELETE</button></a> 
                  </td>    
                  <td> <a  href=add_more_sub.php?tc_id=<?php echo $tcr_data['tc_id']; ?>&username=<?php echo $_GET['username'];?> onClick="return sub()"
                   data-toggle="tooltip" data-placement="top">
                   <button class="btn btn-info">Add more Subject</button></a> </td>   
       
              </tr>
              
          </tbody>

          <?php } ?>
          
    </table>
    <script language="javascript">
         function sub()
         {
          
         return  confirm('Do you want to Add More Subject :');
         }
         </script>
    <script language="javascript">
         function ch()
         {
          
         return  confirm('Do you want to Delete :');
         }
         </script>
  </div>
    

</div>

</center>

</body>
<!-- Body ended  -->

</html>
<!-- data-toggle="tooltip" data-placement="bottom" title="DELETE"> -->
        <!-- <i class="fa fa-trash" aria-hidden="true"></i> -->