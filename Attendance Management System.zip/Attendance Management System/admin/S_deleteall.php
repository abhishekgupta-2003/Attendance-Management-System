<?php
ob_start();
session_start();

if($_SESSION['name']!='oasis')
{

  header('location: ../index.php');
}

?>
<?php
include 'connect.php';
$st_year=$_GET['st_year'];


$sst_id= "2";
$username=$_GET['username'];
// $de="DELETE FROM students WHERE st_id=$_id";
$all_query= "DELETE FROM `students` WHERE `st_year` = '$st_year'";
mysqli_query($conn,$all_query);
 header("location:v-students.php? sst_id=$st_year& username=$username");  


?>