<?php

ob_start();


session_start();

if($_SESSION['name']!='oasis')
{

  header('location: ../index.php');
}



?>
<?php

include('connect.php');
?>
<?php 

$username=$_GET['username'];
//   echo $username;
?>

<!DOCTYPE html>
<html lang="en">

<!-- head started -->
<head>
<title>Mehr Chand Polytechnic College Attendance Management System</title>
<meta charset="UTF-8">

  <link rel="stylesheet" type="text/css" href="../css/main.css">
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
   
  <!-- Optional theme -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
   
  <link rel="stylesheet" href="styles.css" >
   
  <!-- Latest compiled and minified JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
.button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 20px 50px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 25px;
  margin: 170px 100px;
  transition-duration: 0.4s;
  cursor: pointer;
}

.button1 {
  background-color: white; 
  color: black; 
  border: 3px solid #4CAF50;
}

.button1:hover {
  background-color: #4CAF50;
  color: white;
}

.button2 {
  background-color: white; 
  color: black; 
  border: 3px solid #008CBA;
}

.button2:hover {
  background-color: #008CBA;
  color: white;
}

.button3 {
  background-color: white; 
  color: black; 
  border: 3px solid #f44336;
}

.button3:hover {
  background-color: #f44336;
  color: white;
}

.button4 {
  background-color: white;
  color: black;
  border: 3px solid #e7e7e7;
}

.button4:hover {background-color: #e7e7e7;}

.button5 {
  background-color: white;
  color: black;
  border: 3px solid #555555;
}

.button5:hover {
  background-color: #555555;
  color: white;
}
</style>

</head>
<!-- head ended -->

<!-- body started -->
<body>

    <!-- Menus started-->
    <header>

      <h1>Mehr Chand Polytechnic College Attendance Management System</h1>
      <div class="navbar">
         <a href="signup.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Create Users</a>
      <a href="index.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Add Student/Teacher</a>
      <a href="all_stu.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">View Students</a>
      <a href="v-teachers.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">View Teachers</a>
      <a href="Subject.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Add/View Subject</a>
      <a href="change_passA.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Change Password</a>
      <a href="../logout.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Logout</a>
      </div>

    </header>
    


   
 <!-- <?php
    
    $i=0;
       
    $all_query = "SELECT * from students";
   $q= mysqli_query($conn,$all_query);
    
    while ($data = mysqli_fetch_array($q)) {
      $i++;
      $s=$data['st_id'];
    }
    ?> -->


   <center>
    <a href=Add_sub.php?sst_id=<?php echo "2" ?>&username=<?php echo $_GET['username'];?>
    <button class="button button1">Add Subject</button>
    </a>
    <a href=View_sub.php?sst_id=<?php echo "2" ?>&username=<?php echo $_GET['username'];?>>
<button class="button button2"> View Subject</button>
</a>
  </center>
<!-- <a href=v-students.php?sst_id=<?php echo "3" ?>&username=<?php echo $_GET['username'];?>>
<button class="button button3">3rd Year</button>
</a> -->


</body>


</html>
