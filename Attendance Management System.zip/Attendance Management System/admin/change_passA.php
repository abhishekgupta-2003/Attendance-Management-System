<?php

ob_start();
session_start();

if($_SESSION['name']!='oasis')
{

  header('location: ../index.php');
}
// print_r($_SESSION);

?>
<?php include('connect.php');?>
<?php 

$username=$_GET['username'];
  
?>
<!DOCTYPE html>
<html lang="en">

<!-- head started -->
<head>
<title>Mehr Chand Polytechnic College Attendance Management System</title>
<meta charset="UTF-8">
  <link rel="stylesheet" type="text/css" href="../css/main.css">
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
   
  <!-- Optional theme -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
   
  <link rel="stylesheet" href="styles.css" >
   
  <!-- Latest compiled and minified JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>
<!-- head ended -->

<!-- body started -->
<body>

<!-- Menus started-->
<header>

  <h1>Mehr Chand Polytechnic College Attendance Management System</h1>
  <div class="navbar">
  <a href="signup.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Create Users</a>
      <a href="index.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Add Student/Teacher</a>
      <a href="all_stu.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">View Students</a>
      <a href="v-teachers.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">View Teachers</a>
      <a href="Subject.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Add/View Subject</a>
      <a href="change_passA.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Change Password</a>
      <a href="../logout.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Logout</a>

</div>

</header>
<center>
<h1>Change Password</h1>

<div class="content">

  <div class="row">
      
    <?php
    if(isset($success_msg)) echo $success_msg;
    if(isset($error_msg)) echo $error_msg;
     ?>
   
    <?php $username=$_GET['username']; 
    
    // echo $username;
    ?>
    <form method="post" class="form-horizontal col-md-6 col-md-offset-3">

   
    <!-- <div class="form-group">
          <label for="input1" class="col-sm-3 control-label">Roll no</label>
          <div class="col-sm-7">
            <input type="text" name="uname"  class="form-control" id="input1" value="$username" required/>
          </div>
      </div> -->
      

      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label">Enter New Password</label>
          <div class="col-sm-7">
            <input type="password" name="email"  class="form-control" id="input1" placeholder="New Password" required/>
          </div>
      </div>

     

      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label">Confirm Password</label>
          <div class="col-sm-7">
            <input type="password" name="pass"  class="form-control" id="input1" placeholder="Confirm Password" required/>
          </div>
      </div>


     

      <input type="submit" style="border-radius:0%" class="btn btn-primary col-md-3 col-md-offset-8" value=" Change Password" name="Signup" />
  <br>
  <br>
  <?php

if(isset($_POST['Signup']))
{

  $test = $_POST['email'];
  $testn = $_POST['pass'];
if($test==$testn)
{
// echo $test;
// echo $testn;
// echo $_GET['username'];

$re ="UPDATE `admininfo` SET   `pass`='$testn' WHERE username='$_GET[username]'";
mysqli_query($conn,$re);
echo "Your Password is Changed";
}
else{
  echo "Please Enter Valid Password";


}
 

}
   
    ?>
    </form>

    <br>


        
 
  



</center>

</body>
</html>
