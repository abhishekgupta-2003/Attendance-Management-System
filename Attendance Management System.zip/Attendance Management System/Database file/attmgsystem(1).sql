-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 04, 2022 at 08:45 AM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `attmgsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `admininfo`
--

CREATE TABLE IF NOT EXISTS `admininfo` (
  `username` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admininfo`
--

INSERT INTO `admininfo` (`username`, `email`, `pass`, `type`) VALUES
('501/20', 'akash@gmail.com', '501/20', 'student'),
('501/21', 'harsh@gmail.com', '501/21', 'student'),
('502/19', 'abheet@gmail.com', '502/19', 'student'),
('502/20', 'navi@gmail.com', '502/20', 'student'),
('502/21', 'kunal@gmail.com', '502/21', 'student'),
('503/19', 'akash@gmail.com', '503/19', 'student'),
('503/20', 'ravi@gmail.com', '503/20', 'student'),
('503/21', 'rahul@gmail.com', '503/21', 'student'),
('Abhishek', 'abhishek@gmail.com', '1001', 'admin'),
('KCJknkcd', 'taaaaaacfffvfvfvfvfvfvaghi@gam', 'KCJknkcd', 'teacher'),
('Pratham ', 'prathamgrover231@gmail.com', '1001', 'admin'),
('Prince Madaan', 'princemadaan@gmail.com', 'Prince Madaan', 'teacher'),
('Shivam Arora', 'shivammaarora@gmail.com', 'Shivam Arora', 'teacher');

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE IF NOT EXISTS `attendance` (
  `stat_id` varchar(50) NOT NULL,
  `course` varchar(50) NOT NULL,
  `year` varchar(50) NOT NULL,
  `st_status` varchar(50) NOT NULL,
  `stat_date` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`stat_id`, `course`, `year`, `st_status`, `stat_date`) VALUES
('0', '0', '', '0', '0'),
('0', 'course', '', 'st_status', 'dp'),
('0', 'value-2', '', 'value-', 'value-4'),
('0', 'java', '', 'Absent', '2022-04-03-4'),
('0', 'java', '', 'Absent', '2022-04-03-4'),
('0', 'java', '', 'Absent', '2022-04-03-4'),
('0', 'java', '', 'Absent', '2022-04-03-4'),
('0', 'java', '', 'Absent', '2022-04-03-4'),
('0', 'java', '', 'Absent', '2022-04-03-4'),
('0', 'java', '', 'Absent', '2022-04-03-4'),
('0', 'java', '', 'Absent', '2022-04-03-4'),
('0', 'java', '', 'Absent', '2022-04-03-4'),
('0', 'java', '', 'Absent', '2022-04-03-4'),
('0', 'java', '', 'Absent', '2022-04-03-4'),
('0', 'java', '', 'Absent', '2022-04-03-4'),
('0', 'java', '', 'Absent', '2022-04-03-4'),
('0', 'java', '', 'Absent', '2022-04-03-4'),
('0', 'java', '', 'Absent', '2022-04-03-4'),
('0', 'java', '', 'Absent', '2022-04-03-4'),
('0', 'java', '', 'Absent', '2022-04-03-4'),
('0', 'java', '', 'Absent', '2022-04-03-4'),
('0', 'java', '', 'Absent', '2022-04-03-4'),
('0', 'java', '', 'Absent', '2022-04-03-4'),
('502', 'java', '', 'Absent', '2022-04-03-4'),
('503', 'java', '', 'Absent', '2022-04-03-4'),
('508', 'java', '', 'Absent', '2022-04-03-4'),
('510', 'java', '', 'Absent', '2022-04-03-4'),
('502/19', 'python', '', 'Present', '2022-04-03-4'),
('503/19', 'python', '', 'Present', '2022-04-03-4'),
('508/19', 'python', '', 'Present', '2022-04-03-4'),
('510/19', 'python', '', 'Absent', '2022-04-03-4'),
('502/19', 'java', '', 'Absent', '2022-04-04'),
('503/19', 'java', '', 'Absent', '2022-04-04'),
('508/19', 'java', '', 'Absent', '2022-04-04'),
('510/19', 'java', '', 'Absent', '2022-04-04'),
('502/19', 'java', '', 'Absent', '2022-04-04'),
('503/19', 'java', '', 'Absent', '2022-04-04'),
('508/19', 'java', '', 'Absent', '2022-04-04'),
('510/19', 'java', '', 'Absent', '2022-04-04'),
('508/19', 'kl', '', 'Present', '2022-04-05'),
('501/19', '', '', 'Absent', '2022-04-07'),
('502/19', '', '', 'Absent', '2022-04-07'),
('503/19', '', '', 'Absent', '2022-04-07'),
('504/19', '', '', 'Absent', '2022-04-07'),
('505/19', '', '', 'Absent', '2022-04-07'),
('501/19', 'gh', '', 'Absent', '2022-04-07'),
('502/19', 'gh', '', 'Absent', '2022-04-07'),
('503/19', 'gh', '', 'Absent', '2022-04-07'),
('504/19', 'gh', '', 'Absent', '2022-04-07'),
('505/19', 'gh', '', 'Absent', '2022-04-07'),
('501/19', 'cc', '', 'Present', '2022-04-12'),
('502/19', 'cc', '', 'Present', '2022-04-12'),
('503/19', 'cc', '', 'Present', '2022-04-12'),
('504/19', 'cc', '', 'Present', '2022-04-12'),
('505/19', 'cc', '', 'Present', '2022-04-12'),
('501/19', 'cc', '', 'Absent', '2022-04-13'),
('502/19', 'cc', '', 'Absent', '2022-04-13'),
('503/19', 'cc', '', 'Absent', '2022-04-13'),
('504/19', 'cc', '', 'Absent', '2022-04-13'),
('505/19', 'cc', '', 'Absent', '2022-04-13'),
('501/19', 'cc', '', 'Absent', '2022-04-13'),
('502/19', 'cc', '', 'Absent', '2022-04-13'),
('503/19', 'cc', '', 'Absent', '2022-04-13'),
('504/19', 'cc', '', 'Absent', '2022-04-13'),
('505/19', 'cc', '', 'Absent', '2022-04-13'),
('501/19', 'cc', '', 'Absent', '2022-04-13'),
('502/19', 'cc', '', 'Absent', '2022-04-13'),
('503/19', 'cc', '', 'Absent', '2022-04-13'),
('504/19', 'cc', '', 'Absent', '2022-04-13'),
('505/19', 'cc', '', 'Absent', '2022-04-13'),
('501/19', 'cc', '', 'Absent', '2022-04-13'),
('502/19', 'cc', '', 'Absent', '2022-04-13'),
('503/19', 'cc', '', 'Absent', '2022-04-13'),
('504/19', 'cc', '', 'Absent', '2022-04-13'),
('505/19', 'cc', '', 'Absent', '2022-04-13'),
('501/19', 'cc', '', 'Present', '2022-04-13'),
('502/19', 'cc', '', 'Present', '2022-04-13'),
('503/19', 'cc', '', 'Present', '2022-04-13'),
('504/19', 'cc', '', 'Absent', '2022-04-13'),
('505/19', 'cc', '', 'Absent', '2022-04-13'),
('501/19', 'Cloud Computing', '', 'Present', '2022-04-13'),
('502/19', 'Cloud Computing', '', 'Present', '2022-04-13'),
('503/19', 'Cloud Computing', '', 'Present', '2022-04-13'),
('504/19', 'Cloud Computing', '', 'Absent', '2022-04-13'),
('505/19', 'Cloud Computing', '', 'Absent', '2022-04-13'),
('501/19', 'Operating System', '', 'Present', '2022-04-22'),
('502/19', 'Operating System', '', 'Present', '2022-04-22'),
('503/19', 'Operating System', '', 'Absent', '2022-04-22'),
('504/19', 'Operating System', '', 'Absent', '2022-04-22'),
('505/19', 'Operating System', '', 'Absent', '2022-04-22'),
('501/19', 'kklklklkl', '', 'Absent', '2022-04-25'),
('502/19', 'kklklklkl', '', 'Absent', '2022-04-25'),
('503/19', 'kklklklkl', '', 'Absent', '2022-04-25'),
('504/19', 'kklklklkl', '', 'Absent', '2022-04-25'),
('505/19', 'kklklklkl', '', 'Absent', '2022-04-25'),
('540/19', 'kklklklkl', '', 'Absent', '2022-04-25'),
('501/20', 'dsf,jkjdkf,kklklklkl', '', 'Absent', '2022-04-25'),
('510/19', 'dsf,jkjdkf,kklklklkl', '', 'Absent', '2022-04-25'),
('501/20', 'dsf,jkjdkf,kklklklkl', '', 'Absent', '2022-04-25'),
('510/19', 'dsf,jkjdkf,kklklklkl', '', 'Absent', '2022-04-25'),
('501/19', 'jkjdkf', '', 'Absent', '2022-04-26'),
('501/20', 'jkjdkf', '', 'Absent', '2022-04-26'),
('508/20', 'jkjdkf', '', 'Absent', '2022-04-26'),
('501/20', 'jkjdkf', '', 'Absent', '2022-04-26'),
('508/20', 'jkjdkf', '', 'Absent', '2022-04-26'),
('501/20', 'jkjdkf', '1', 'Present', '2022-04-26'),
('508/20', 'jkjdkf', '1', 'Present', '2022-04-26'),
('501/19', 'dsf,jkjdkf', '3', 'Absent', '2022-04-27'),
('502/20', 'dsf,jkjdkf', '3', 'Absent', '2022-04-27'),
('503/22', 'dsf,jkjdkf', '3', 'Absent', '2022-04-27'),
('570/19', 'dsf,jkjdkf', '3', 'Absent', '2022-04-27'),
('501/19', 'java', '1', 'Absent', '2022-04-27'),
('502/19', 'java', '1', 'Absent', '2022-04-27'),
('503/19', 'java', '1', 'Absent', '2022-04-27'),
('501/19', 'java', '3', 'Present', '2022-04-29'),
('502/19', 'java', '3', 'Present', '2022-04-29'),
('503/19', 'java', '3', 'Present', '2022-04-29'),
('501/19', 'Operating System', '3', 'Present', '2022-05-02'),
('502/19', 'Operating System', '3', 'Present', '2022-05-02'),
('503/19', 'Operating System', '3', 'Present', '2022-05-02'),
('501/19', 'CC', '3', 'Present', '2022-05-04'),
('502/19', 'CC', '3', 'Present', '2022-05-04'),
('503/19', 'CC', '3', 'Absent', '2022-05-04'),
('501/19', 'CC', '3', 'Present', '2022-05-04'),
('502/19', 'CC', '3', 'Present', '2022-05-04'),
('503/19', 'CC', '3', 'Present', '2022-05-04');

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE IF NOT EXISTS `reports` (
  `st_id` varchar(30) NOT NULL,
  `course` varchar(30) NOT NULL,
  `st_status` varchar(30) NOT NULL,
  `st_name` varchar(30) NOT NULL,
  `st_dept` varchar(30) NOT NULL,
  `st_batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE IF NOT EXISTS `students` (
  `st_id` varchar(20) NOT NULL,
  `st_name` varchar(20) NOT NULL,
  `st_dept` varchar(20) NOT NULL,
  `st_batch` int(4) NOT NULL,
  `st_year` varchar(50) NOT NULL,
  `st_email` varchar(30) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`st_id`, `st_name`, `st_dept`, `st_batch`, `st_year`, `st_email`, `username`, `password`) VALUES
('501/21', 'Harsh', 'CSE', 2021, '1', 'harsh@gmail.com', 'Harsh', '501/21'),
('502/21', 'kunal', 'CSE', 2021, '1', 'kunal@gmail.com', 'kunal', '502/21'),
('503/21', 'Rahul', 'CSE', 2021, '1', 'rahul@gmail.com', 'Rahul', '503/21');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE IF NOT EXISTS `subject` (
`id` int(50) NOT NULL,
  `Subject` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`id`, `Subject`) VALUES
(11, 'Java'),
(12, 'Python'),
(13, 'Operating System'),
(14, 'Cloud Computing'),
(15, 'CC'),
(16, 'ADA'),
(17, 'Major Project');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE IF NOT EXISTS `teachers` (
`tc_id` int(50) NOT NULL,
  `tc_name` varchar(50) NOT NULL,
  `tc_dept` varchar(50) NOT NULL,
  `tc_email` varchar(50) NOT NULL,
  `tc_course` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`tc_id`, `tc_name`, `tc_dept`, `tc_email`, `tc_course`, `username`, `password`) VALUES
(84, 'Shivam Arora', 'CSE', 'shivammaarora@gmail.com', 'Major Project', 'Shivam Arora', 'Shivam Arora');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admininfo`
--
ALTER TABLE `admininfo`
 ADD PRIMARY KEY (`username`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
 ADD PRIMARY KEY (`st_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
 ADD PRIMARY KEY (`st_id`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
 ADD PRIMARY KEY (`tc_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
MODIFY `id` int(50) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
MODIFY `tc_id` int(50) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=85;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
