<?php
ob_start();
?>


<?php

include('connect.php');

  

?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Attendance Management System</title>
<meta charset="UTF-8">
  
  <link rel="stylesheet" type="text/css" href="css/main.css">
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
   
  <!-- Optional theme -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
   
  <link rel="stylesheet" href="styles.css" >
   
  <!-- Latest compiled and minified JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<header>

  <h1>Attendance Management System</h1>

</header>
<center>
<h1>Signup</h1>
<div class="content">

  <div class="row">
    <?php
    if(isset($success_msg)) echo $success_msg;
    if(isset($error_msg)) echo $error_msg;
     ?>
    <!-- Old version started -->
    <!--<form action="" method="post">
      
      <table>
        
        <tr>
          <td>Email</td>
          <td><input type="text" name="email"></td>
        </tr>
        <tr>
          <td>Username</td>
          <td><input type="text" name="uname"></td>

        </tr>
        <tr>
          <td>Password</td>
          <td><input type="Password" name="pass"></td>
        </tr>

        <tr>
          <td>Full Name</td>
          <td><input type="text" name="fname"></td>
        </tr>

        <tr>
          <td>Phone Number</td>
          <td><input type="text" name="phone"></td>
        </tr>

        <tr>
          <td>Type</td>
          <td>      <select name="type">
        <option name="teacher" value="teacher">Teacher</option>
        <option name="student" value="student">Student</option>
      </select></td>
        </tr>

        <tr><td><br></td></tr>
        <tr>
          <td></td>
          <td><input type="submit" name="signup" value="Signup"></td>
        </tr>

      </table>
    </form>--><!-- Old version ended -->

    <form method="post" class="form-horizontal col-md-6 col-md-offset-3">

    
    <div class="form-group">
          <label for="input1" class="col-sm-3 control-label">Username</label>
          <div class="col-sm-7">
            <input type="text" name="uname"  class="form-control" id="input1" placeholder="Choose Username" required/>
          </div>
      </div>
      

      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label">Email</label>
          <div class="col-sm-7">
            <input type="email" name="email"  class="form-control" id="input1" placeholder="Your Email" required/>
          </div>
      </div>

     

      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label">Password</label>
          <div class="col-sm-7">
            <input type="password" name="pass"  class="form-control" id="input1" placeholder="Enter Password" required/>
          </div>
      </div>


      <div class="form-group" class="radio">
      <label for="input1" class="col-sm-3 control-label">User Role:</label>
      <div class="col-sm-7">
        <label>
          <input type="radio" name="type" id="optionsRadios1" value="student" checked> Student
        </label>
            <label>
          <input type="radio" name="type" id="optionsRadios1" value="teacher"> Teacher
        </label>
        <!-- <label>
          <input type="radio" name="type" id="optionsRadios1" value="admin"> Admin
        </label> -->
      </div>
      </div>

      <input type="submit" style="border-radius:0%" class="btn btn-primary col-md-2 col-md-offset-8" value="Signup" name="signup" />
    </form>

    <br>

<?php

    if(isset($_POST['signup'])){
      $test = $_POST['email'];
      $testn = $_POST['uname'];
   
      if( $_POST["type"] == 'teacher'){
        $row = 0;
        $query = mysql_query("SELECT tc_name, tc_email from teachers where tc_name='$testn'  and tc_email = '$test'");
        $row = mysql_num_rows($query);
         
        if ($row !==1)
        {
         
    ?>
   <center>  <div class="content"> <h2><p> Please enter valid username and passowrd </p></h2></div></center>
   
    <?php
        }
        else
        {
    
          $result = mysql_query("insert into admininfo(username,email,pass,type) values('$_POST[uname]','$_POST[email]','$_POST[pass]','$_POST[type]')");
          $success_msg="Signup Successfully!";
       
        ?>
        
        <?php
    
      
    }}

    elseif( $_POST["type"] == 'student'){
      $row = 0;
      $query = mysql_query("SELECT st_name, st_email from students where st_name='$testn'  and st_email = '$test'");
      $row = mysql_num_rows($query);
       
      if ($row !==1){
       
  ?>
    <div class="content" > <h2><p> Please enter valid Username and Email </p></h2></div>
   
  <?php
      }
      else{
  
        $result = mysql_query("insert into admininfo(username,email,pass,type) values('$_POST[uname]','$_POST[email]','$_POST[pass]','$_POST[type]')");
        $success_msg="Signup Successfully!";
     
      ?>
      
      <?php
  
    
  }}
  

  
  
  
  }
    ?>
      
   

  </div>
  <br>

  <br>

  <p><strong>Already have an account? <a href="index.php">Login</a> here.</strong></p> 

</div>



</center>

</body>
</html>
