<?php
ob_start();

	    session_start();
?>
<?php
if(isset($_POST['login']))
{
	//start of try block
	$email=$_POST['email'];

	try{

		//checking empty fields
		if(empty($_POST['email'])){
			throw new Exception("Username is required!");
			
		}
		if(empty($_POST['Password'])){
			throw new Exception("Password is required!");
			
		}
		//establishing connection with db and things
		include ('connect.php');
		
		//checking login info into database
		$row=0;
		$result="select * from admininfo where email='$_POST[email]' and pass='$_POST[Password]' and type='$_POST[type]'";
	    $ro = mysqli_query($conn,$result);
		$row=mysqli_num_rows($ro);
	
		$username= mysqli_fetch_array($ro);
		$username=$username['username'];

		if($row>0 && $_POST["type"] == 'teacher'){
		 
  session_start();
			$_SESSION['name']="oasi";
  
  header("location: teacher/index.php? username=$username");

		
			// header('location: teacher/index.php');
// 			header("location: teacher/index.php? username=$username");
		}

		else if($row>0 &&  $_POST["type"] == 'student'){
	
  session_start();
			$_SESSION['name']="oasiss";
  
			// header('location: student/index.php');
			header("location: student/index.php? username=$username");

		}

		else if($row>0 && $_POST["type"] == 'admin'){
	
	    session_start();
			$_SESSION['name']="oasis";
			header("location: admin/index.php?username=$username");
		    
		}

		else{
			
			throw new Exception("Username,Password or Role is wrong, try again!");
			
			header('location: login.php');
		}
	}
	
	//end of try block
	catch(Exception $e){
		$error_msg=$e->getMessage();
	}
	//end of try-catch
}

?>
<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="en">
<head>
<title>Mehr Chand Polytechnic College Attendance Management System Website</title>
<!-- Meta tag Keywords -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Awesome Login Form Responsive Widget,Login form widgets, Sign up Web forms , Login signup Responsive web form,Flat Pricing table,Flat Drop downs,Registration Forms,News letter Forms,Elements" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Meta tag Keywords -->
<!-- css files -->
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" /> <!-- Style-CSS --> 
<link rel="stylesheet" href="css/font-awesome.css"> <!-- Font-Awesome-Icons-CSS -->
<!-- //css files -->
<!-- web-fonts -->
<link href="//fonts.googleapis.com/css?family=Philosopher:400,400i,700,700i&amp;subset=cyrillic,cyrillic-ext,vietnamese" rel="stylesheet">
<!-- //web-fonts -->
<style>
	/*--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
--*/
/* reset */
html,body,div,span,applet,object,iframe,h1,h2,h3,h4,h5,h6,p,blockquote,pre,a,abbr,acronym,address,big,cite,code,del,dfn,em,img,ins,kbd,q,s,samp,small,strike,strong,sub,sup,tt,var,b,u,i,dl,dt,dd,ol,nav ul,nav li,fieldset,form,label,legend,table,caption,tbody,tfoot,thead,tr,th,td,article,aside,canvas,details,embed,figure,figcaption,footer,header,hgroup,menu,nav,output,ruby,section,summary,time,mark,audio,video{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline;color:#fff;}
article, aside, details, figcaption, figure,footer, header, hgroup, menu, nav, section {display: block;}
ol,ul{list-style:none;margin:0px;padding:0px;}
blockquote,q{quotes:none;}
blockquote:before,blockquote:after,q:before,q:after{content:'';content:none;}
table{border-collapse:collapse;border-spacing:0;}
/* start editing from here */
a{text-decoration:none;}
.txt-rt{text-align:right;}/* text align right */
.txt-lt{text-align:left;}/* text align left */
.txt-center{text-align:center;}/* text align center */
.float-rt{float:right;}/* float right */
.float-lt{float:left;}/* float left */
.clear{clear:both;}/* clear float */
.pos-relative{position:relative;}/* Position Relative */
.pos-absolute{position:absolute;}/* Position Absolute */
.vertical-base{	vertical-align:baseline;}/* vertical align baseline */
.vertical-top{	vertical-align:top;}/* vertical align top */
nav.vertical ul li{	display:block;}/* vertical menu */
nav.horizontal ul li{	display: inline-block;}/* horizontal menu */
img{max-width:100%;}
/*end reset*/

body {
    text-align: center;
	font-family: 'Philosopher', sans-serif;
}
.center-container {
    padding: 0;
    background: rgba(0, 0, 0, 0.62);
}
/*--header--*/
.header-w3l {
    padding: 3em 0;
}
.header-w3l h1{
	font-size:3em;
    color:#fff;
    letter-spacing: 4px;
    text-transform: uppercase;
}
/*--//header--*/

/*--main--*/
.main-content-agile {
    margin: 0 auto;
    background: rgba(0, 0, 0, 0.21);
    width: 34%;
}
.wthree-pro {
    background:rgba(0, 0, 0, 0.52);
    background-size: cover;
    -webkit-background-size: cover;
    -moz-background-size: cover;
    -o-background-size: cover;
}
.wthree-pro h2 {
    font-size: 1.7em;
    color: #fff;
    letter-spacing: 1px;
    padding: 1em 0;
    font-weight: 600;
}
.sub-main-w3{
	position:relative;
	padding: 3em;
}
.sub-main-w3 input[type="email"], .sub-main-w3 input[type="password"] {
    outline: none;
    font-size: 1em;
    border: none;
    border-bottom: 1px dotted #fff;
    background: none;
    width: 92.5%;
    color: #fff;
    padding: 1em 0 1em 2em;
    letter-spacing: 1px;
    font-family: 'Philosopher', sans-serif;
}
.sub-main-w3 input[type="password"]{
	margin-top: 1.5em;
}
.sub-main-w3 input[type="submit"] {
    color: #fff;
    background: #2CC990;
    border: none;
    padding: .5em 4em;
    outline: none;
    font-size: 1.2em;
    cursor: pointer;
    letter-spacing: 1px;
	margin-top: 2.5em;
    transition: 0.5s all;
    -webkit-transition: 0.5s all;
    -o-transition: 0.5s all;
    -moz-transition: 0.5s all;
    -ms-transition: 0.5s all;
	font-family: 'Philosopher', sans-serif;
}
.sub-main-w3 input[type="submit"]:hover {
    background: #fff;
    color: #000;
}
span.icon1, span.icon2 {
    color: #fff;
    font-size: 1em;
	position: absolute;
}
span.icon1 {
    top: 15%;
}
span.icon2 {
    top: 32%;
}
span.icon1, span.icon2{
	right: 87%;
}
.rem-w3 {
    margin:2em 0 2.5em;
}
span.check-w3 {
    float: left;
    color: #fff;
    font-size: 1em;
    letter-spacing: 1px;
}
.sub-main-w3 a {
    color: #fff;
    float: right;
    font-size: 1em;
}
/*-- social-icons --*/
.social-icons ul li {
    display: inline-block;
}
.social-icons ul li a.fa {
    font-size: 0.9em;
    line-height: 2.8em;
    text-align: center;
    margin: 0 5px;
    width: 38px;
    height: 38px;
}
.icon-border {
	position: relative;
} 
.icon-border::before,
.icon-border::after {
	display: block;
	position: absolute;
	top: 0;
	left: 0;
	width: 100%;
	height: 100%;
	content: "";
} 
.icon-border::before {
	z-index: 1;
	-webkit-transition: box-shadow 0.3s;
	-moz-transition: box-shadow 0.3s;
	-o-transition: box-shadow 0.3s;
	-ms-transition: box-shadow 0.3s;
    transition: box-shadow 0.3s;      
} 
.icon-border::before {
	-webkit-box-shadow: inset 0 0 0 3px #fff; 
	-moz-box-shadow: inset 0 0 0 3px #fff; 
	-o-box-shadow: inset 0 0 0 3px #fff; 
	-ms-box-shadow: inset 0 0 0 3px #fff; 
	box-shadow: inset 0 0 0 3px #fff; 
}  
/* facebook */
.icon-border.facebook:hover::before {
	-webkit-box-shadow: inset 0 0 0 48px #3b5998; 
	-moz-box-shadow: inset 0 0 0 48px #3b5998; 
	-o-box-shadow: inset 0 0 0 48px #3b5998; 
	-ms-box-shadow: inset 0 0 0 48px #3b5998; 
	box-shadow: inset 0 0 0 48px #3b5998; 
}  
/* twitter */
.icon-border.twitter:hover::before {
	-webkit-box-shadow: inset 0 0 0 48px #4099ff;
	-moz-box-shadow: inset 0 0 0 48px #4099ff;
	-o-box-shadow: inset 0 0 0 48px #4099ff;
	-ms-box-shadow: inset 0 0 0 48px #4099ff;
	box-shadow: inset 0 0 0 48px #4099ff;
}  
/* google plus */
.icon-border.googleplus:hover::before {
	-webkit-box-shadow: inset 0 0 0 48px #d34836;
	-moz-box-shadow: inset 0 0 0 48px #d34836;
	-o-box-shadow: inset 0 0 0 48px #d34836;
	-ms-box-shadow: inset 0 0 0 48px #d34836;
	box-shadow: inset 0 0 0 48px #d34836;
}   
/* rss */
.icon-border.rss:hover::before {
	-webkit-box-shadow: inset 0 0 0 48px #C92228;
	-moz-box-shadow: inset 0 0 0 48px #C92228;
	-o-box-shadow: inset 0 0 0 48px #C92228;
	-ms-box-shadow: inset 0 0 0 48px #C92228;
	box-shadow: inset 0 0 0 48px #C92228;
}  
/*-- //social-icons --*/   
/*--//main--*/

/*--footer--*/
.footer {
    padding:2.05em 0;
}
.footer p {
    font-size: 1em;
    color: #fff;
    letter-spacing: 2px;
}
.footer p a {
    color:#2CC990;
}
.footer p a:hover {
   text-decoration:underline;
}
/*--//footer--*/
/*--responsive--*/
@media(max-width: 1440px){
	.header-w3l h1 {
		font-size: 2.8em;
	}
	.wthree-pro h2 {
		font-size: 1.5em;
	}
	.header-w3l {
		padding: 2.5em 0;
	}
	.main-content-agile {
		width: 38%;
	}
	.footer {
		padding: 3em 0;
	}
}
@media(max-width: 1366px){
	.main-content-agile {
		width: 40%;
	}
}
@media(max-width: 1280px){
	.main-content-agile {
		width: 43%;
	}
}
@media(max-width: 1080px){
	.header-w3l h1 {
		font-size: 2.6em;
	}
	.wthree-pro h2 {
		font-size: 1.4em;
	}
	.main-content-agile {
		width: 49%;
	}
}
@media(max-width: 1024px){
	.main-content-agile {
		width: 51%;
	}
	.header-w3l {
		padding: 2em 0;
	}
	.footer {
		padding: 2.5em 0;
	}
	.sub-main-w3 input[type="email"], .sub-main-w3 input[type="password"] {
		width: 92%;
	}
	span.icon1, span.icon2 {
		right: 86%;
	}
}
@media(max-width: 991px){
	.header-w3l h1 {
		font-size: 2.5em;
		letter-spacing: 3px;
	}
}
@media(max-width: 800px){
	.header-w3l h1 {
		font-size: 2.2em;
	}
	.main-content-agile {
		width: 61%;
	}
	.sub-main-w3 input[type="email"], .sub-main-w3 input[type="password"] {
		width: 91%;
	}
	.sub-main-w3 input[type="submit"] {
		margin-top: 2em;
	}
	span.icon1, span.icon2 {
		right: 85%;
	}
}
@media(max-width: 768px){
	.header-w3l {
		padding: 3em 0 6em;
	}
	.footer {
		padding: 6.8em 0 7em;
	}
	.main-content-agile {
		width: 65%;
	}
}
@media(max-width: 736px){
	.header-w3l {
		padding: 2em 0;
	}
	.footer {
		padding: 2.5em 0;
	}	
}
@media(max-width: 667px){
	.wthree-pro h2 {
		font-size: 1.35em;
	}
	.main-content-agile {
		width: 70%;
	}
	.header-w3l h1 {
		letter-spacing: 2px;
	}
}
@media(max-width: 640px){
	.main-content-agile {
		width: 75%;
	}
	.footer p {
		letter-spacing: 1px;
	}
}
@media(max-width: 600px){
	.header-w3l h1 {
		font-size: 2.1em;
	}
	.wthree-pro h2 {
		font-size: 1.3em;
	}
	.main-content-agile {
		width: 77%;
	}
}
@media(max-width: 568px){
	.main-content-agile {
		width: 80%;
	}
	.footer p {
		line-height: 1.9;
	}
	.footer {
		padding: 2em 0;
	}
	.sub-main-w3 input[type="email"], .sub-main-w3 input[type="password"] {
		width: 90%;
	}
	span.icon1, span.icon2 {
		right: 84%;
	}
}
@media(max-width: 480px){
	.header-w3l {
		padding: 1.5em 0;
	}
	.header-w3l h1 {
		font-size: 2em;
	}
	.main-content-agile {
		width: 86%;
	}
	.sub-main-w3 {
		padding: 2em;
	}
	span.icon1, span.icon2 {
		right: 86%;
	}
	span.icon1 {
		top: 12%;
	}
	span.icon2 {
		top: 31%;
	}
}
@media(max-width: 414px){
	.header-w3l h1 {
		font-size: 1.7em;
	}
	.wthree-pro h2 {
		font-size: 1.2em;
	}
	span.check-w3 {
		font-size: .9em;
	}
	.sub-main-w3 a {
		font-size: .9em;
	}
	.social-icons ul li a.fa {
		margin: 0 4px;
		width: 36px;
		height: 36px;
	}
	.sub-main-w3 input[type="submit"] {
		padding: .5em 3em;
	}
	.footer p {
		font-size: 0.9em;
	}
	.header-w3l {
		padding: 2em 0;
	}
	.sub-main-w3 input[type="email"], .sub-main-w3 input[type="password"] {
		width: 89%;
	}
	span.icon1, span.icon2 {
		right: 85%;
	}
}
@media(max-width: 384px){
	.header-w3l h1 {
		font-size: 1.6em;
		letter-spacing: 1px;
	}
	.header-w3l {
		padding: 1.5em 0;
	}
	.main-content-agile {
		width: 89%;
	}
	span.icon1, span.icon2 {
		right: 84%;
	}
}
@media(max-width: 375px){
	.sub-main-w3 {
		padding: 1.8em;
	}
	.wthree-pro h2 {
		font-size: 1.1em;
	}
	.sub-main-w3 input[type="email"], .sub-main-w3 input[type="password"] {
		font-size: 0.9em;
	}
	span.icon1, span.icon2 {
		right: 85%;
	}
	span.icon1 {
		top: 11%;
	}
	span.icon2 {
		top: 28%;
	}
	.sub-main-w3 input[type="submit"] {
		padding: .4em 3em;
		margin-top: 1.8em;
	}
	.footer {
		padding: 1.5em 0;
	}
}
@media(max-width: 320px){
	.header-w3l h1 {
		font-size: 1.4em;
	}
	.wthree-pro h2 {
		font-size: 1.05em;
		padding: 0.8em 0;
	}
	.sub-main-w3 {
		padding: 1em;
	}
	.sub-main-w3 input[type="email"], .sub-main-w3 input[type="password"] {
		width: 87%;
	}
	.sub-main-w3 input[type="password"] {
		margin-top: 1em;
	}
	span.icon1, span.icon2 {
		right: 86%;
	}
	span.icon1 {
		top: 10.1%;
	}
	span.icon2 {
		top: 27%;
	}
	span.check-w3 {
		font-size: .85em;
	}
	.sub-main-w3 a {
		font-size: .85em;
	}
	.rem-w3 {
		margin: 2em 0 2em;
	}
	.social-icons ul li a.fa {
		font-size: 0.8em;
	}
	.sub-main-w3 input[type="submit"]{
		font-size: 1em;
		padding: .5em 2.5em;
	}
}
/*--//responsive--*/

</style>
<script>
	function myFunction() {
  var x = document.getElementById("myInput");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>
</head>
<body>
<div data-vide-bg="video/social2">
	<div class="center-container">
		<!--header-->
		<div class="header-w3l">
			<h1>Attendance Management System</h1>
		</div>
		<!--//header-->
		<!--main-->
		<div class="main-content-agile">
			<div class="wthree-pro">
				<h2>Login Now</h2>
			</div>

			<?php
//printing error message
if(isset($error_msg))
{
	echo $error_msg;
}
?>

			<div class="sub-main-w3">	
				<form  method="POST">
					<input placeholder="E-mail" name="email" type="email" required="">
					<span class="icon1"><i class="fa fa-user" aria-hidden="true"></i></span>
					<input  placeholder="Password" name="Password" id="myInput" type="password" required="">
					<span class="icon2"><i class="fa fa-unlock" aria-hidden="true"></i></span>
					
					<div class="rem-w3">
						<!-- <span class="check-w3"><input type="checkbox" onclick="myFunction()" />Show Password</span> -->
						
						<a href="reset.php">Forgot Password?</a>
						<div class="clear"></div>
					</div> 
					<div class="form-group" class="radio">
			<label for="input1" class="col-sm-3 control-label">Login As:</label>
			<div class="col-sm-6"><br>
			  <label>
			    <input type="radio" name="type" id="optionsRadios1" value="student" checked> Student
			  </label>
			  	  <label>
			    <input type="radio" name="type" id="optionsRadios1" value="teacher"> Teacher
			  </label>
			  <label>
			    <input type="radio" name="type" id="optionsRadios1" value="admin"> Admin
			  </label>
			</div>
			</div>  
					<input type="submit" name="login" value="Login">
				</form>
			</div>
		</div>
		<!--//main-->
		
		<!--footer-->
		<div class="footer">
			<p>&copy;Copyright 2022 Mehr Chand Polytechnic College. All rights reserved | Design by Abhishek & Pratham.</p>
		</div>
		<!--//footer-->
	</div>
</div>
<!-- js -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<script src="js/jquery.vide.min.js"></script>
<!-- //js -->
</body>
<br>
<br>
</html>