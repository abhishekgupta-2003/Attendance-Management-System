<?php

$conn=mysqli_connect('localhost','root','','attmgsystem') ;
if(!$conn)
{

    echo "not";
}

else
{

    echo "connect";
}
?>