<?php

$conn = mysqli_connect('localhost','root','','attmgsystem') ;
if(!$conn)
{

    echo "Database is not connected";
}


?>