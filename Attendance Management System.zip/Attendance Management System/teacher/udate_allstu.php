<?php

ob_start();
session_start();

if($_SESSION['name']!='oasi')
{

  header('location: ../index.php');
}
?>

<?php

include('connect.php'); 

//data insertion
  

     if(isset($_POST['tcru'])){
      $st_year=$_GET['st_year'];

    $res = mysql_query("UPDATE `students` SET  `st_year`='$_POST[year]' WHERE st_year='$st_year'");
    $success_msg = "Teacher added successfully.";

    }


    
 ?>



<!DOCTYPE html>
<html lang="en">
<!-- head started -->
<head>
<title>Mehr Chand Polytechnic College Attendance Management System</title>
<meta charset="UTF-8">

  <link rel="stylesheet" type="text/css" href="../css/main.css">
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
   
  <!-- Optional theme -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
   
  <link rel="stylesheet" href="styles.css" >
   
  <!-- Latest compiled and minified JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style type="text/css">

  .message{
    padding: 10px;
    font-size: 15px;
    font-style: bold;
    color: black;
  }
</style>
</head>
<!-- head ended -->

<!-- body started -->
<body>

    <!-- Menus started-->
    <header>

      <h1>Mehr Chand Polytechnic College Attendance Management System</h1>
      <div class="navbar">
<a href="index.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Home</a>
  <a href="all_stu.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Students</a>
  <a href="teachers.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Faculties</a>
  <a href="attendance.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Attendance</a>
  <a href="report.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Report</a>
  <a href="change_passT.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Change Password</a>
  <a href="../logout.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Logout</a>

    </div>

    </header>
    <!-- Menus ended -->

<center>
<!-- Error or Success Message printint started -->
<div class="message">
        <?php if(isset($success_msg)) echo $success_msg; if(isset($error_msg)) echo $error_msg; ?>
</div>
<!-- Error or Success Message printint ended -->

<!-- Content, Tables, Forms, Texts, Images started -->
<div class="content">

<br><br><br>
  <div class="rowtwo" id="teacher">
  

       <form method="post" class="form-horizontal col-md-6 col-md-offset-3">
       

      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label">Enter Year</label>
          <div class="col-sm-7">
            <input type="text" name="year"   class="form-control" id="input1" placeholder="year"  required/>
          </div>
      </div>

      
     

      <input type="submit" class="btn btn-primary col-md-2 col-md-offset-8" value="teacher" name="tcru" required/>
    </form>
    
  </div>
 <?php

    ?>

</div><br>
<!-- Contents, Tables, Forms, Images ended -->

</center>
</body>
<!-- Body ended  -->
</html>
  
