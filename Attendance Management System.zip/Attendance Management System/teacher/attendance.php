<?php

ob_start();

session_start();

if($_SESSION['name']!='oasi')
{

  header('location: ../index.php');
}

?>


<strong>


         

<strong>



       


 

<!DOCTYPE html>
<html lang="en">
<head>
<title>Mehr Chand Polytechnic College Attendance Management System</title>
<meta charset="UTF-8">

  <link rel="stylesheet" type="text/css" href="../css/main.css">
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
   
  <!-- Optional theme -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
   
  <link rel="stylesheet" href="styles.css" >
   
  <!-- Latest compiled and minified JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


<style type="text/css">
  .status{
    font-size: 10px;
  }

</style>

</head>
<body>

<header>

  <h1>Mehr Chand Polytechnic College Attendance Management System</h1>
  <div class="navbar">
  <a href="index.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Home</a>
  <a href="all_stu.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Students</a>
  <a href="teachers.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Faculties</a>
  <a href="attendance.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Attendance</a>
  <a href="report.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Report</a>
  <a href="all_stu_report.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Total Report</a>
  <a href="change_passT.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Change Password</a>
  <a href="../logout.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Logout</a>

</div>

</header>
<center>
<?php

    include('connect.php');
   
    ?>  
     <?php 

      $tc_course=" ";
     
      if(isset($_POST['batch'])){
      
        $test = $_POST['tc_name'];
        
        $query = "select tc_name from teachers where tc_name = '$test'";
        $re =  mysqli_query($conn,$query);
        $row = mysqli_num_rows($re);
      

        if($row == 0){
?>
    <div  class="content"><p>Please Enter the valid Teacher name</p></div>

<?php
        }

        else
        {
           
    $test = $_POST['whichbatch'];
    $row = 0;
    $query = "SELECT st_year from students where st_year ='$test'";
   $re = mysqli_query($conn,$query);
    $row = mysqli_num_rows($re);
    // $course=$ros['st_course'];
    if($row == 0){
?>
<div  class="content"><p>Please valid batch </p></div>
<?php
    }
  }}
 
   

    elseif(isset($_POST['att'])){

      $whichbatch = $_POST['tc_name'];

        foreach ($_POST['st_status'] as $i => $st_status) {
          
          $stat_id = $_POST['stat_id'][$i];
          $course = $_POST['course'];
          $dp = date('Y-m-d');
        
       
          $stat =" INSERT INTO `attendance`(`stat_id`, `course`,`Year`, `st_status`, `stat_date`) VALUES ('$stat_id','$course','$whichbatch','$st_status','$dp')";
          mysqli_query($conn,$stat);
          // INSERT INTO `attendance`(`stat_id`, `course`, `st_status`, `stat_date`) VALUES ('stat_id-1','course','st_status','dp-4')
          $att_msg = "Attendance Recorded.";
          
        
      }
?>
<?php


}
      

 ?></center>

<center>
<?php $username=$_GET['username'];?>
<div class="row">

  <div class="content">
    <h3>Attendance of <?php echo date('Y-m-d'); ?></h3>
    <br>


     <!-- //Teacher -->
     <!-- <form action="" method="post" class="form-horizontal col-md-2 col-md-offset-3">
    <div class="form-group">
     <label>Enter name</label>
          <input type="text" name="tc_name" id="input2"   placeholder="nmae 2020">
     </div>
     <input type="submit" class="btn btn-danger col-md-5 col-md-offset-5" style="border-radius:0%" value="find" name="findt" />

     </form> -->

    <center><p><?php if(isset($att_msg)) echo $att_msg; if(isset($error_msg)) echo $error_msg; ?></p></center> 
    
    <form action="" method="post" class="form-horizontal col-md-6 col-md-offset-3">

     <!-- //Teacher
    <form action="" method="post" class="form-horizontal col-md-2 col-md-offset-3">
    <div class="form-group">
     <label>Enter Batch</label>
          <input type="text" name="whichbatch" id="input2" placeholder="Only 2020">
     </div>
     </form> -->
     
     <div class="form-group">
     <label>Enter name</label>
          <input type="text" name="tc_name" id="input2"   placeholder="Enter Teacher name" value="<?php echo $_GET['username']; ?>" >
     </div>


     <div class="form-group">
                <label>Enter year</label>
                <!-- <input type="text" name="whichbatch" id="input2" placeholder="Enter the Year"  required/> -->
                <select name="whichbatch" id="input2" value="whichbatch" >
  <option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>

</select>
              </div>
               
     <input type="submit" class="btn btn-danger col-md-2 col-md-offset-5" style="border-radius:0%" value="Search" name="batch" />

    </form>
 <button  class="btn btn-success col-md-2 col-md-offset-10" onclick="window.print()">Print</button>
    <div class="content"></div>
    
    <form action="" method="post">

      <div class="form-group">
     
        <label for="input2"  >Choose Subject</label>
        
        <?php
        if(isset($_POST['batch'])){
  ?>
        <select name="course">
     
        <?php
           $tc_name = $_POST['tc_name'];
       $qu = "SELECT tc_course FROM teachers  WHERE tc_name='$tc_name'";
      $re= mysqli_query($conn,$qu);
       $row1 = mysqli_num_rows($re);
     $r=mysqli_fetch_array($re);
    $h=explode(',',$r['tc_course']);
    
    foreach($h as$d)
    {
      ?>
      
        <option  >  <?php echo  $d."<br>"; ?></option>
        

     
      <?php
    }
       }
         ?>

    
        

    </select>

      </div>

    <table class="table table-stripped">
      <thead>
        <tr>
                     
        
           <th scope="col">Email</th>
        
          <th scope="col">Department</th>
          <th scope="col">Batch</th>
          <th scope="col">Year</th>
            <th scope="col">Name</th>
           <th scope="col">Roll No.</th>
          <th scope="col">Status</th>
        </tr>
      </thead>
   <?php
   if(isset($_POST['batch'])){
     $batch = $_POST['whichbatch'];
    $row = 0;
    $query = "select st_batch from students where students.st_year = '$batch' order by st_id asc";
    $re=mysqli_query($conn,$query);
    $row = mysqli_num_rows($re);

    if($row1 >0){
      

    if(isset($_POST['batch'])){

     $i=0;
     $radio = 0;
     $batch = $_POST['whichbatch'];
     $all_query = "select * from students where students.st_year = '$batch' order by st_id asc";
     
   $res=  mysqli_query($conn,$all_query);

     while ($data = mysqli_fetch_array($res)) {
       $i++;

           ?>
  <body>
     <tr>
       <td><?php echo $data['st_email']; ?> </td>
   
       <td><?php echo $data['st_dept']; ?></td>
       <td><?php echo $data['st_batch']; ?></td>
       <td><?php echo $data['st_year']; ?></td>
           <td><?php echo $data['st_name']; ?></td>
       <td><?php echo $data['st_id']; ?> <input type="hidden" name="stat_id[]" value="<?php echo $data['st_id']; ?>">
       </td>
       <td>
         <label>Present</label>
         <input type="radio" name="st_status[<?php echo $radio; ?>]" value="Present" >
         <label>Absent </label>
         <input type="radio" name="st_status[<?php echo $radio; ?>]" value="Absent" checked>
       </td>
     </tr>
  </body>

     <?php

        $radio++;
      } 
}}}
      ?>
    </table>
    <input type="hidden" name="tc_name" id="input2"   placeholder="Enter Teacher name" value="<?php echo $_POST['whichbatch']; ?>" >

    <center><br>
    
    <input type="submit" class="btn btn-primary col-md-2 col-md-offset-10" value="Save!" name="att" onClick="return ch()" />
    <script language="javascript">
         function ch()
         {
          
         return  confirm('Are you sure to save Attendance :');
         }
         </script>
  </center>

</form>
  </div>

</div>

</center>

</body>
</br>
</br>
</html>
