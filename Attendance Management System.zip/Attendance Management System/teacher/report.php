<?php

ob_start();
session_start();

if($_SESSION['name']!='oasi')
{

  header('location: ../index.php');
}
 ?>
<?php include('connect.php');?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Mehr Chand Polytechnic College Attendance Management System</title>
<meta charset="UTF-8">

  <link rel="stylesheet" type="text/css" href="../css/main.css">
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
   
  <!-- Optional theme -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
   
  <link rel="stylesheet" href="styles.css" >
   
  <!-- Latest compiled and minified JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>
<body>

<header>

  <h1>Mehr Chand Polytechnic College Attendance Management System</h1>
  <div class="navbar">
  <a href="index.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Home</a>
  <a href="all_stu.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Students</a>
  <a href="teachers.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Faculties</a>
  <a href="attendance.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Attendance</a>
  <a href="report.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Report</a>
  <a href="all_stu_report.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Total Report</a>
  <a href="change_passT.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Change Password</a>
  <a href="../logout.php" style="text-decoration:none;">Logout</a>

</div>

</header>

<center>
<?php 

$username=$_GET['username'];
  
?>
<div class="row">

  <div class="content">
    <h2>Individual Report</h2>

    <form method="post" action="">

    <label>Select Subject</label>
    <select name="whichcourse">
    
      <?php
       $qu ="SELECT Subject FROM subject";
      $re= mysqli_query($conn,$qu);
       while($r=mysqli_fetch_array($re))
       {
      
      ?>
        <option  >  <?php echo $r['Subject']; ?></option>

     
      <?php

       }
         ?>
    </select>

      <p>  </p>
      <label>Roll no.</label>
      <input type="text" name="sr_id">
      <input type="submit" name="sr_btn" value="Go!" >

    </form>

    <h2>Mass Report</h2>

    <form method="post" action="">

    <label>Select Subject</label>
    <select name="course">
      <?php
       $qu = "SELECT Subject FROM subject";
    $re =  mysqli_query($conn,$qu);
       while($r=mysqli_fetch_array($re))
       {
      
      ?>
        <option  >  <?php echo $r['Subject']; ?></option>

     
      <?php

       }
         ?>
        

    </select>
    <p>  </p>
      <label>Date ( yyyy-mm-dd )</label>
      <input type="date" name="date">
      <br>
      <br>
      <label ">Enter year</label>
  
                <!-- <input type="text" name="whichbatch" id="input2" placeholder="Enter the Year"  required/> -->
                <select name="year" id="input2" value="whichbatch">
  <option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>

</select>
             

      <input type="submit" name="sr_date" value="Go!" >
    </form>

    <h2> One Day Report</h2>
    <form method="post" action="">

<label>Select Subject</label>
<select name="course1">
  <?php
   $qu = "SELECT Subject FROM subject";
  $re= mysqli_query($conn,$qu);
   while($r=mysqli_fetch_array($re))
   {
  
  ?>
    <option  >  <?php echo $r['Subject']; ?></option>

 
  <?php

   }
     ?>
    

</select>
<p>  </p>
  <label>Date ( yyyy-mm-dd )</label>
  <input type="date" name="date1">
<br>
<br>
  <label>Roll no.</label>
  <input type="text" name="roll">

  <input type="submit" name="sr_date1" value="Go!" >
</form>

    <br>

    <br>
<button  class="btn btn-success col-md-2 col-md-offset-10" onclick="window.print()">Print</button>
    <div class="content"></div>
   <?php

    if(isset($_POST['sr_btn'])){

     $sr_id = $_POST['sr_id'];
     $course = $_POST['whichcourse'];

     $single = "select stat_id,count(*) as countP from attendance where attendance.stat_id='$sr_id' and attendance.course = '$course' and attendance.st_status='Present'";
      $singleT= "select count(*) as countT from attendance where attendance.stat_id='$sr_id' and attendance.course = '$course'";
     $si= mysqli_query($conn,$single);
      $sin=  mysqli_query($conn,$singleT);
    //  $count_tot = mysql_num_rows($singleT);
  } 

    if(isset($_POST['sr_date'])){

     $sdate = $_POST['date'];
     $course = $_POST['course'];
     $year = $_POST['year'];
    //  $roll1 = $_POST['roll'];

     $all_query1 = "select * from  attendance where attendance.stat_date='$sdate' and attendance.course = '$course' and attendance.year='$year'";
    $re= mysqli_query($conn,$all_query1);

    }

    if(isset($_POST['sr_date'])){

      ?>

    <table class="table table-stripped">
      <thead>
        <tr>
        
          <th scope="col">Subject</th>
          <th scope="col">year</th>
          <th scope="col">Date</th>
            <th scope="col">Roll no</th>
          <th scope="col">Attendance Status</th>
          
        </tr>
     </thead>


    <?php

     $i=0;
     while ($data = mysqli_fetch_array($re)) {

       $i++;

     ?>
        <tbody>
           <tr>
             
             <td><?php echo $data['course'] ?></td>
             <td><?php echo $data['Year'] ?></td>
             <td><?php echo $data['stat_date'] ?></td>
             <td><?php echo $data['stat_id'] ?></td>
             <td><?php echo $data['st_status'] ?></td>
            
           </tr>
        </tbody>

     <?php 
   } 
  }
     ?>
     
    </table>

    <?php
      if(isset($_POST['sr_date1'])){

        $sdate = $_POST['date1'];
        $course = $_POST['course1'];
        $roll1 = $_POST['roll'];
   
        $all_query = "select * from  attendance where attendance.stat_date='$sdate' and attendance.course = '$course' and attendance.stat_id = '$roll1'  ";
       $re= mysqli_query($conn,$all_query);
   
       }
       if(isset($_POST['sr_date1'])){

        ?>
  
      <table class="table table-stripped">
        <thead>
          <tr>
            <th scope="col">Roll no</th>
            <th scope="col">Subject</th>
            <th scope="col">Date</th>
            <th scope="col">Attendance Status</th>
            
          </tr>
       </thead>
  
  
      <?php
  
       $i=0;
       while ($data1 = mysqli_fetch_array($re)) {
  
         $i++;
  
       ?>
          <tbody>
             <tr>
               <td><?php echo $data1['stat_id'] ?></td>
               <td><?php echo $data1['course'] ?></td>
               <td><?php echo $data1['stat_date'] ?></td>
               <td><?php echo $data1['st_status'] ?></td>
              
             </tr>
          </tbody>
  
       <?php 
     } 
    }
       ?>
       
      </table>
 

    <form method="post" action="" class="form-horizontal col-md-6 col-md-offset-3">
    <table class="table table-striped">

    <?php


    if(isset($_POST['sr_btn'])){

       $count_pre = 0;
       $i= 0;
       $count_tot;
       if ($row=mysqli_fetch_row($sin))
       {
       $count_tot=$row[0];
       }
       while ($data = mysqli_fetch_array($si)) {
       $i++;
       
       if($i <= 1){
     ?>


     <tbody>
      <tr>
          <td>Student Roll No: </td>
          <td><?php echo $data['stat_id']; ?></td>
      </tr>

           <?php
         //}
        
        // }

      ?>
      
      <tr>
        <td>Total Class (Days): </td>
        <td><?php echo $count_tot; ?> </td>
      </tr>

      <tr>
        <td>Present (Days): </td>
        <td><?php echo $data[1]; ?> </td>
      </tr>

      <tr>
        <td>Absent (Days): </td>
        <td><?php echo $count_tot -  $data[1]; ?> </td>
      </tr>

    </tbody>

   <?php

     }  
    }}
     ?>
    </table>
  </form>

  </div>

</div>

</center>

</body>
</html>