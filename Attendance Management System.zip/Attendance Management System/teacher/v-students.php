<?php

ob_start();
session_start();

if($_SESSION['name']!='oasi')
{

  header('location: ../index.php');
}
?>


<?php

//establishing connection
include('connect.php');


?>

<!DOCTYPE html>
<html lang="en">

<!-- head started -->
<head>
<title>Mehr Chand Polytechnic College Attendance Management System</title>
<meta charset="UTF-8">

  <link rel="stylesheet" type="text/css" href="../css/main.css">
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
   
  <!-- Optional theme -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
   
  <link rel="stylesheet" href="styles.css" >
   
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>

<body>

    
    <header>

      <h1>Mehr Chand Polytechnic College Attendance Management System</h1>
      <div class="navbar">
<a href="index.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Home</a>
  <a href="all_stu.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Students</a>
  <a href="teachers.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Faculties</a>
  <a href="attendance.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Attendance</a>
  <a href="report.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Report</a>
  <a href="all_stu_report.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Total Report</a>
  <a href="change_passT.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Change Password</a>
  <a href="../logout.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Logout</a>
      </div>

    </header>
    <!-- Menus ended -->

<center>
<h1>All Students</h1>
<?php 

$username=$_GET['username'];
// echo $username;
  
?>
<div class="content">



  <div class="row">
   
  


    <table class="table table-striped table-hover">
      
        <thead>
        <tr>
          <th scope="col">Registration No.</th>
          <th scope="col">Name</th>
          <th scope="col">Department</th>
          <th scope="col">Batch</th>
          <!-- <th scope="col">Semester</th> -->
          <th scope="col">Year</th>
          <th scope="col">Email</th>
         
        </tr>
        </thead>
     <?php
     if($_GET['st_id']==1 )
{      
       $i=0;
       
       $all_query ="SELECT * from students WHERE st_year=1 ";
       $re = mysqli_query($conn,$all_query);
       
       while ($data = mysqli_fetch_array($re)) {
         $i++;
         
       ?>
  <div >
     
</div>
       <tr>
         <td><?php echo $data['st_id']; ?></td>
         <td><?php echo $data['st_name']; ?></td>
         <td><?php echo $data['st_dept']; ?></td>
         <td><?php echo $data['st_batch']; ?></td>
         
         <td><?php echo $data['st_year']; ?></td>
         <td><?php echo $data['st_email']; ?></td>
         
       </tr>
  
       <?php 
            } 
}
// 2nd
elseif($_GET['st_id']==2 )
{      
       $i=0;
       
       $all_query = "SELECT * from students WHERE st_year=2 ";
       $re=mysqli_query($conn,$all_query);
       
       while ($data = mysqli_fetch_array($re)) {
         $i++;
         
       ?>
  
       <tr>
         <td><?php echo $data['st_id']; ?></td>
         <td><?php echo $data['st_name']; ?></td>
         <td><?php echo $data['st_dept']; ?></td>
         <td><?php echo $data['st_batch']; ?></td>
         
         <td><?php echo $data['st_year']; ?></td>
         <td><?php echo $data['st_email']; ?></td>
        
       </tr>
  
       <?php 
            } 
}
elseif($_GET['st_id']==3   )
{      
       $i=0;
       
       $all_query = "SELECT * from students WHERE st_year=3  ";
       $re=mysqli_query($conn,$all_query);
       
       while ($data = mysqli_fetch_array($re)) {
         $i++;
         
       ?>
  
       <tr>
         <td><?php echo $data['st_id']; ?></td>
         <td><?php echo $data['st_name']; ?></td>
         <td><?php echo $data['st_dept']; ?></td>
         <td><?php echo $data['st_batch']; ?></td>
        
         <td><?php echo $data['st_year']; ?></td>
         <td><?php echo $data['st_email']; ?></td>
         
       </tr>
  
       <?php 
            } 
} 

        ?>  
        
      </table>
    
  </div>
 
</div>


</center>

</body>


</html>
