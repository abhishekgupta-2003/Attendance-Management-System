<?php

ob_start();
session_start();

if($_SESSION['name']!='oasi')
{

  header('location: ../index.php');
}
?>


<?php

//establishing connection
include('connect.php');


?>

<!DOCTYPE html>
<html lang="en">

<!-- head started -->
<head>
<title>Mehr Chand Polytechnic College Attendance Management System</title>
<meta charset="UTF-8">

  <link rel="stylesheet" type="text/css" href="../css/main.css">
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
   
  <!-- Optional theme -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
   
  <link rel="stylesheet" href="styles.css" >
   
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>

<body>

    
    <header>

      <h1>Mehr Chand Polytechnic College Attendance Management System</h1>
      <div class="navbar">
      <a href="index.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Home</a>
  <a href="all_stu.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Students</a>
  <a href="teachers.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Faculties</a>
  <a href="attendance.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Attendance</a>
  <a href="report.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Report</a>
   <a href="all_stu_report.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Total Report</a>
  <a href="change_passT.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Change Password</a>
  <a href="../logout.php" style="text-decoration:none;">Logout</a>
      </div>

    </header>
    <!-- Menus ended -->

<center>
<h1>All Students</h1>
<?php 

// $username=$_GET['username'];
// echo $username;
  
?>
<div class="content">


<button  class="btn btn-success col-md-2 col-md-offset-10" onclick="window.print()">Print</button>
    <div class="content"></div>
  <div class="row">
   
  


    <table class="table table-striped table-hover">
      
        <thead>
        <tr>
     <th scope="col">Subject</th>
          <th scope="col">year</th>
          <th scope="col">Date</th>
        <th scope="col">Roll no</th>
          <th scope="col">Attendance Status</th>
         
        </tr>
        </thead>
     <?php
    
       $i=0;
       
      $all_query = "select * from  attendance ";
       $re= mysqli_query($conn,$all_query);
     $i=0;
     while ($data = mysqli_fetch_array($re)) {

       $i++;
         
       ?>
  <div >
     
</div>
       <tr>
          <td><?php echo $data['course'] ?></td>
             <td><?php echo $data['Year'] ?></td>
             <td><?php echo $data['stat_date'] ?></td>
             <td><?php echo $data['stat_id'] ?></td>
             <td><?php echo $data['st_status'] ?></td>
       </tr>
  
       <?php 
            } 


?>
        
      </table>
    
  </div>
 
</div>


</center>

</body>


</html>
