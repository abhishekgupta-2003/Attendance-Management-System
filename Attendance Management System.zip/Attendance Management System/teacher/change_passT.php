<?php

ob_start();
session_start();

if($_SESSION['name']!='oasi')
{

  header('location: ../index.php');
}
?>
<?php include('connect.php');?>

<!DOCTYPE html>
<html lang="en">

<!-- head started -->
<head>
<title>Mehr Chand Polytechnic College Attendance Management System</title>
<meta charset="UTF-8">
  <link rel="stylesheet" type="text/css" href="../css/main.css">
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
   
  <!-- Optional theme -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
   
  <link rel="stylesheet" href="styles.css" >
   
  <!-- Latest compiled and minified JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>
<!-- head ended -->

<!-- body started -->
<body>

<!-- Menus started-->
<header>

  <h1>Mehr Chand Polytechnic College Attendance Management System</h1>
  <div class="navbar">
  <a href="index.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Home</a>
  <a href="all_stu.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Students</a>
  <a href="teachers.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Faculties</a>
  <a href="attendance.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Attendance</a>
  <a href="report.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Report</a>
  <a href="all_stu_report.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Total Report</a>
  <a href="change_passT.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Change Password</a>
  <a href="../logout.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Logout</a>

</div>

</header>
<center>
<h1>Change Password</h1>
<div class="content">

  <div class="row">
    <?php
    if(isset($success_msg)) echo $success_msg;
    if(isset($error_msg)) echo $error_msg;
     ?>
    <!-- Old version started -->
    <!--<form action="" method="post">
      
      <table>
        
        <tr>
          <td>Email</td>
          <td><input type="text" name="email"></td>
        </tr>
        <tr>
          <td>Username</td>
          <td><input type="text" name="uname"></td>

        </tr>
        <tr>
          <td>Password</td>
          <td><input type="Password" name="pass"></td>
        </tr>

        <tr>
          <td>Full Name</td>
          <td><input type="text" name="fname"></td>
        </tr>

        <tr>
          <td>Phone Number</td>
          <td><input type="text" name="phone"></td>
        </tr>

        <tr>
          <td>Type</td>
          <td>      <select name="type">
        <option name="teacher" value="teacher">Teacher</option>
        <option name="student" value="student">Student</option>
      </select></td>
        </tr>

        <tr><td><br></td></tr>
        <tr>
          <td></td>
          <td><input type="submit" name="signup" value="Signup"></td>
        </tr>

      </table>
    </form>--><!-- Old version ended -->
    <?php $username=$_GET['username']; 
    
    // echo $username;
    ?>
    <form method="post" class="form-horizontal col-md-6 col-md-offset-3">

    
    <!-- <div class="form-group">
          <label for="input1" class="col-sm-3 control-label">Roll no</label>
          <div class="col-sm-7">
            <input type="text" name="uname"  class="form-control" id="input1" value="$username" required/>
          </div>
      </div> -->
      

      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label">Enter New Password</label>
          <div class="col-sm-7">
            <input type="password" name="email"  class="form-control" id="input1" placeholder="New Password" required/>
          </div>
      </div>

     

      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label">Confirm Password</label>
          <div class="col-sm-7">
            <input type="password" name="pass"  class="form-control" id="input1" placeholder="Confirm Password" required/>
          </div>
      </div>


     

      <input type="submit" style="border-radius:0%" class="btn btn-primary col-md-3 col-md-offset-8" value=" Change Password" name="Signup" />
    </form>

    <br>

<?php

    if(isset($_POST['Signup']))
    {

      $test = $_POST['email'];
      $testn = $_POST['pass'];
   if($test==$testn)
   {
// echo $test;
// echo $testn;
// echo $_GET['username'];

    $re ="UPDATE `admininfo` SET   `pass`='$testn' WHERE username='$_GET[username]'";
    mysqli_query($conn,$re);
   echo "Your Password is Changed";
   }
   else{
      echo "Please Enter Valid Password";


   }
     
    
    }
       
        ?>
        
 
  



</center>

</body>
</html>
