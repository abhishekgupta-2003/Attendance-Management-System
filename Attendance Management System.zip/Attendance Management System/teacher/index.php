<?php
ob_start();
session_start();

if($_SESSION['name']!='oasi')
{

  header('location: ../index.php');
}
// print_r($_SESSION);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Mehr Chand Polytechnic College Attendance Management System</title>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="../css/main.css">

</head>
<body>

<header>

  <h1>Mehr Chand Polytechnic College Attendance Management System</h1>
  <div class="navbar">
  <a href="index.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Home</a>
  <a href="all_stu.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Students</a>
  <a href="teachers.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Faculties</a>
  <a href="attendance.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Attendance</a>
  <a href="report.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Report</a>
  
    <a href="all_stu_report.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Total Report</a>
  <a href="change_passT.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Change Password</a>
  <a href="../logout.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Logout</a>

</div>

</header>

<center>
  <h1>
  Teacher Name :
<?php 

$username=$_GET['username'];
  echo $username; 
?>
</h1>
<img src="welcome-4737158_960_720.webp" width="1000" alt="#" 
     height="535"/>
<div class="row">





</div>

</center>

</body>
</html>
