<?php

ob_start();
session_start();

if($_SESSION['name']!='oasi')
{

  header('location: ../index.php');
}

?>


<?php

include('connect.php');


?>

<!DOCTYPE html>
<html lang="en">

<!-- head started -->
<head>
<title>Mehr Chand Polytechnic College Attendance Management System</title>
<meta charset="UTF-8">

  <link rel="stylesheet" type="text/css" href="../css/main.css">
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
   
  <!-- Optional theme -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
   
  <link rel="stylesheet" href="styles.css" >
   
  <!-- Latest compiled and minified JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
.button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 20px 50px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 25px;
  margin: 140px 150px;
  transition-duration: 0.4s;
  cursor: pointer;
}

.button1 {
  background-color: white; 
  color: black; 
  border: 3px solid #4CAF50;
}

.button1:hover {
  background-color: #4CAF50;
  color: white;
}

.button2 {
  background-color: white; 
  color: black; 
  border: 3px solid #008CBA;
}

.button2:hover {
  background-color: #008CBA;
  color: white;
}

.button3 {
  background-color: white; 
  color: black; 
  border: 3px solid #f44336;
}

.button3:hover {
  background-color: #f44336;
  color: white;
}

.button4 {
  background-color: white;
  color: black;
  border: 3px solid #e7e7e7;
}

.button4:hover {background-color: #e7e7e7;}

.button5 {
  background-color: white;
  color: black;
  border: 3px solid #555555;
}

.button5:hover {
  background-color: #555555;
  color: white;
}
</style>

</head>
<!-- head ended -->

<!-- body started -->
<body>

    <!-- Menus started-->
    <header>

      <h1>Mehr Chand Polytechnic College Attendance Management System</h1>
      <div class="navbar">
<a href="index.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Home</a>
  <a href="all_stu.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Students</a>
  <a href="teachers.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Faculties</a>
  <a href="attendance.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Attendance</a>
  <a href="report.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Report</a>
  <a href="all_stu_report.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Total Report</a>
  <a href="change_passT.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Change Password</a>
  <a href="../logout.php?username=<?php echo $_GET['username']; ?>" style="text-decoration:none;">Logout</a>
      </div>

    </header>
  

<?php 

$username=$_GET['username'];
// echo $username;
?>
   
   <a href=v-students.php?st_id=<?php echo "1" ?>&username=<?php echo $username; ?>>
    <button class="button button1">1st Year</button>
    </a>
    <a href=v-students.php?st_id=<?php echo "2" ?>&username=<?php echo $_GET['username']; ?>>
<button class="button button2">2nd Year</button>
</a>
<a href=v-students.php?st_id=<?php echo "3" ?>&username=<?php echo $_GET['username']; ?>>
<button class="button button3">3rd Year</button>
</a>

</body>
<br>
<br>

</html>
